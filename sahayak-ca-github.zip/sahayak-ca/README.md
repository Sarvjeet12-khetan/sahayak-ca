# Sahayak CA — Bharat Tax & GST Assistant

> An all-in-one Indian Chartered Accountant assistant for everyday use by individuals and small businesses. Easy enough for non-technical users, powerful enough for real tax work.

![Tech Stack](https://img.shields.io/badge/Stack-Next.js%2016%20%2B%20TypeScript%20%2B%20Tailwind%20%2B%20Prisma-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Tax Year](https://img.shields.io/badge/Tax%20Year-FY%202025--26%20(AY%202026--27)-orange)

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Screenshots](#screenshots)
- [Quick Start](#quick-start)
- [Project Structure](#project-structure)
- [How the LLM is Integrated](#how-the-llm-is-integrated)
- [Configuration](#configuration)
- [Deployment](#deployment)
- [Disclaimer](#disclaimer)
- [License](#license)

---

## Overview

**Sahayak CA** (Hindi for "Assistant CA") is a full-stack web application that acts as a personal Chartered Accountant. It handles the work a CA typically does — tax calculation, GST filing prep, invoicing, bookkeeping, and compliance reminders — in a simple, form-based interface that anyone can use.

The app supports **3 languages**: English, हिंदी (Hindi), and Hinglish — making it accessible to users across India who may not be comfortable with English-only tax tools.

### Who is it for?

- **Individual taxpayers** — salaried employees who want to estimate tax, choose between regimes, and track deductions
- **Small business owners** — shopkeepers, freelancers, consultants who need GST invoicing and basic bookkeeping
- **First-time tax filers** — people who find government portals confusing and want a simpler starting point

---

## Features

| # | Feature | Description |
|---|---------|-------------|
| 1 | **Dashboard** | Snapshot of finances, invoices this month, upcoming reminders |
| 2 | **GST Tools** | GST calculator (add/remove tax, CGST/SGST/IGST split) + GSTR-1/3B summary generator |
| 3 | **Income Tax Calculator** | Live calculation under new & old regime, advance tax schedule, regime comparison |
| 4 | **Invoice Builder** | GST-compliant invoices with HSN/SAC codes, auto tax calculation, save & print |
| 5 | **Bookkeeping** | Income/expense tracking with auto-generated Profit & Loss statement |
| 6 | **AI Chat Advisor** | Chat with an AI Chartered Accountant in English/Hindi/Hinglish |
| 7 | **Compliance Calendar** | Auto-populated GST/ITR/advance tax due dates + custom reminders |

### Key Highlights

- ✅ **Trilingual UI** — Switch between English / Hindi / Hinglish instantly
- ✅ **Trusted Gov design** — Navy + saffron theme with India tricolor accent
- ✅ **Mobile responsive** — Bottom nav on mobile, horizontal tabs on desktop
- ✅ **Offline-capable math** — All tax/GST calculations done client-side (instant, no waiting)
- ✅ **AI for reasoning, not math** — LLM is only used for chat questions, not calculations
- ✅ **Persistent data** — Profile, invoices, transactions, chat history saved to SQLite

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| **Framework** | Next.js 16 (App Router) |
| **Language** | TypeScript 5 |
| **Styling** | Tailwind CSS 4 + shadcn/ui (New York) |
| **Database** | Prisma ORM + SQLite |
| **State** | Zustand (client) + React Query (server) |
| **Forms** | React Hook Form + Zod |
| **LLM SDK** | z-ai-web-dev-sdk |
| **Icons** | Lucide React |
| **Fonts** | Inter (body) + Lora (serif headings) |

---

## Screenshots

> _Add screenshots here after running the app_

```
1. Dashboard with snapshot cards
2. GST Calculator in action
3. Income Tax Calculator showing regime comparison
4. AI Chat Advisor answering a tax question
5. Invoice Builder with auto GST calculation
6. Hindi language UI
```

---

## Quick Start

### Prerequisites

- **Node.js 20+** or **Bun 1.3+**
- npm or bun package manager

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/sahayak-ca.git
cd sahayak-ca

# 2. Install dependencies
bun install
# OR
npm install --legacy-peer-deps

# 3. Set up environment variables
cp .env.example .env
# Edit .env with your database URL

# 4. Set up the database
bun run db:push
# OR
npx prisma db push

# 5. Start the development server
bun run dev
# OR
npm run dev
```

Open **http://localhost:3000** in your browser.

### First Run

1. The app will prompt you to set up your profile (name, PAN, GSTIN, state)
2. After saving, you'll see the dashboard
3. Click any tab to start using the features

---

## Project Structure

```
sahayak-ca/
├── prisma/
│   └── schema.prisma              # Database models (Profile, Invoice, Transaction, etc.)
│
├── src/
│   ├── app/
│   │   ├── api/                   # Backend API routes
│   │   │   ├── chat/route.ts     # ★ LLM integration (AI chat)
│   │   │   ├── profile/route.ts  # User profile CRUD
│   │   │   ├── invoices/route.ts # Invoice CRUD
│   │   │   ├── transactions/     # Bookkeeping CRUD
│   │   │   └── reminders/        # Reminder CRUD
│   │   ├── page.tsx               # Main page
│   │   ├── layout.tsx             # Root layout + fonts
│   │   └── globals.css            # Navy + saffron theme
│   │
│   ├── components/
│   │   ├── ui/                    # shadcn/ui base components
│   │   └── ca/                    # App-specific components
│   │       ├── Header.tsx
│   │       ├── TabNav.tsx
│   │       ├── Dashboard.tsx
│   │       ├── GSTTools.tsx
│   │       ├── IncomeTax.tsx
│   │       ├── InvoiceBuilder.tsx
│   │       ├── Bookkeeping.tsx
│   │       ├── AIAdvisor.tsx      # ★ LLM chat UI
│   │       ├── Reminders.tsx
│   │       ├── ProfileSetup.tsx
│   │       └── Footer.tsx
│   │
│   └── lib/
│       ├── indianTax.ts           # GST + income tax calculation logic
│       ├── i18n.ts                # English/Hindi/Hinglish translations
│       └── db.ts                  # Prisma client
│
├── public/                        # Static assets
├── prisma/                        # Database schema
├── .env.example                   # Environment template
├── .gitignore
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── README.md
```

---

## How the LLM is Integrated

The LLM (Large Language Model) is used in **one specific feature: the "Ask CA (AI)" chat tab**. All other features (GST calc, tax slabs, invoices) use pure TypeScript math — no AI needed.

### Architecture

```
User types question
       ↓
[Frontend: AIAdvisor.tsx]
  - Adds message to chat UI
  - Calls fetch("/api/chat", { message, language, history })
       ↓
[Backend: api/chat/route.ts]
  - Picks system prompt for user's language (EN/Hindi/Hinglish)
  - Builds messages array = [system, ...history, user_message]
  - Calls ZAI.create() → zai.chat.completions.create({ messages })
       ↓
[z-ai-web-dev-sdk → LLM]
  - Generates answer using system prompt + conversation context
       ↓
[Backend]
  - Saves user message + AI reply to SQLite
  - Returns { reply: "..." } JSON
       ↓
[Frontend]
  - Displays AI reply in chat UI
```

### The Key Code

```typescript
// src/app/api/chat/route.ts
import ZAI from "z-ai-web-dev-sdk";

const SYSTEM_PROMPTS = {
  en: `You are "Sahayak CA", an expert Indian Chartered Accountant...
       New regime slabs: 0% up to ₹4L, 5% ₹4L-8L, 10% ₹8L-12L, ...
       Standard deduction ₹75,000. Rebate u/s 87A: no tax up to ₹12L.`,
  hi: `आप "सहायक CA" हैं... (same in Hindi)`,
  hinglish: `Tum "Sahayak CA" ho... (same in Hinglish)`,
};

export async function POST(req) {
  const { message, language, history } = await req.json();

  const messages = [
    { role: "system", content: SYSTEM_PROMPTS[language] },
    ...history.slice(-10),
    { role: "user", content: message },
  ];

  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages,
    temperature: 0.4,        // Low = factual answers
    max_tokens: 1500,
  });

  const reply = completion.choices[0].message.content;

  // Save to database
  await db.chatMessage.create({
    data: [
      { role: "user", content: message },
      { role: "assistant", content: reply },
    ],
  });

  return Response.json({ reply });
}
```

### 5 Key Design Decisions

1. **Strong system prompt** — Indian tax slabs injected directly into the prompt
2. **Trilingual prompts** — Separate system prompt per language
3. **Conversation memory** — Last 10 messages sent as context
4. **Low temperature (0.4)** — Factual, consistent answers (not creative)
5. **Database persistence** — Chat history saved for return visits

---

## Configuration

### Environment Variables

Create a `.env` file in the project root:

```env
# Database (SQLite)
DATABASE_URL="file:./db/custom.db"
```

### z-ai SDK Setup

The `z-ai-web-dev-sdk` requires a `.z-ai-config` file with your API credentials:

```json
{
  "baseUrl": "https://api.example.com/v1",
  "apiKey": "YOUR_API_KEY"
}
```

> ⚠️ **Never commit `.z-ai-config` or `.env` to GitHub** — they're already in `.gitignore`

### Tax Year Configuration

The app uses **FY 2025-26 / AY 2026-27** slabs (Budget 2025). To update for future years, edit `src/lib/indianTax.ts`:

```typescript
export const NEW_REGIME_SLABS = [
  { upTo: 400000, rate: 0 },      // Update these slabs
  { upTo: 800000, rate: 0.05 },
  // ...
];
```

---

## Deployment

### Deploy to Vercel (Recommended)

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) and sign in with GitHub
3. Click **"New Project"** → import your repo
4. Add environment variables:
   - `DATABASE_URL` — use a PostgreSQL connection string (Vercel Postgres or Neon)
5. Click **"Deploy"**

> Note: For production, switch from SQLite to PostgreSQL by updating `prisma/schema.prisma`:
> ```prisma
> datasource db {
>   provider = "postgresql"  // was "sqlite"
>   url = env("DATABASE_URL")
> }
> ```

### Deploy to other platforms

The app is a standard Next.js 16 project — works on:
- **Netlify** — supports Next.js SSR
- **Railway** — full Node.js hosting
- **Render** — free tier available
- **Self-hosted** — `bun run build && bun run start`

---

## Disclaimer

**Sahayak CA is an independent tool and is NOT affiliated with the Government of India.**

- Tax calculations are based on FY 2025-26 / AY 2026-27 slabs announced in Budget 2025
- GST rates reflect the September 2025 slab restructure
- Always verify tax/GST details on official portals before filing:
  - Income Tax: [incometax.gov.in](https://www.incometax.gov.in)
  - GST: [gst.gov.in](https://www.gst.gov.in)
  - GST rates by HSN: [cbic-gst.gov.in](https://cbic-gst.gov.in)
- This tool is for guidance only and is **not a substitute for a professional CA**

---

## License

MIT License — see [LICENSE](LICENSE) file for details.

You are free to:
- ✅ Use this project for personal or commercial purposes
- ✅ Modify and distribute
- ✅ Use in class projects and presentations

---

## Credits

Built with:
- [Next.js](https://nextjs.org)
- [Tailwind CSS](https://tailwindcss.com)
- [shadcn/ui](https://ui.shadcn.com)
- [Prisma](https://prisma.io)
- [z-ai-web-dev-sdk](https://www.npmjs.com/package/z-ai-web-dev-sdk)
- [Lucide Icons](https://lucide.dev)

---

## Star this Repo ⭐

If this project helped you, please star it on GitHub!
