"use client";

import { useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { INDIAN_STATES } from "@/lib/indianTax";
import { toast } from "sonner";
import { Loader2, User, Building2 } from "lucide-react";
import type { ProfileData } from "./types";

interface ProfileSetupProps {
  open: boolean;
  onClose: () => void;
  onSaved?: (profile: ProfileData) => void;
}

export function ProfileSetup({ open, onClose, onSaved }: ProfileSetupProps) {
  const { t } = useI18n();
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ProfileData>({
    name: "",
    pan: "",
    gstin: "",
    aadhaar: "",
    mobile: "",
    email: "",
    address: "",
    state: "",
    userType: "individual",
    businessName: "",
    regime: "new",
  });

  // Load existing profile
  useEffect(() => {
    if (open) {
      setLoading(true);
      fetch("/api/profile")
        .then((r) => r.json())
        .then((res) => {
          if (res.profile) {
            setData({
              name: res.profile.name || "",
              pan: res.profile.pan || "",
              gstin: res.profile.gstin || "",
              aadhaar: res.profile.aadhaar || "",
              mobile: res.profile.mobile || "",
              email: res.profile.email || "",
              address: res.profile.address || "",
              state: res.profile.state || "",
              userType: res.profile.userType || "individual",
              businessName: res.profile.businessName || "",
              regime: res.profile.regime || "new",
            });
          }
        })
        .finally(() => setLoading(false));
    }
  }, [open]);

  const update = (k: keyof ProfileData, v: any) => setData((p) => ({ ...p, [k]: v }));

  const handleSave = async () => {
    if (!data.name.trim()) {
      toast.error("Please enter your name");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success(t("profileSaved"));
      onSaved?.(data);
      onClose();
    } catch (e) {
      toast.error("Failed to save profile");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto ca-scroll">
        <DialogHeader>
          <DialogTitle className="font-serif text-xl">{t("profileTitle")}</DialogTitle>
          <DialogDescription>{t("profileDesc")}</DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-4">
            {/* User type */}
            <div className="space-y-2">
              <Label>{t("userType")}</Label>
              <RadioGroup
                value={data.userType}
                onValueChange={(v) => update("userType", v as any)}
                className="grid grid-cols-2 gap-3"
              >
                <Label
                  htmlFor="ut-ind"
                  className={`flex flex-col items-start gap-1 rounded-md border-2 p-3 cursor-pointer transition-colors ${data.userType === "individual" ? "border-primary bg-primary/5" : "border-border"}`}
                >
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="individual" id="ut-ind" />
                    <User className="h-4 w-4" />
                    <span className="font-medium text-sm">{t("individual")}</span>
                  </div>
                  <p className="text-xs text-muted-foreground ml-6">Salaried / self-employed person</p>
                </Label>
                <Label
                  htmlFor="ut-bus"
                  className={`flex flex-col items-start gap-1 rounded-md border-2 p-3 cursor-pointer transition-colors ${data.userType === "small_business" ? "border-primary bg-primary/5" : "border-border"}`}
                >
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="small_business" id="ut-bus" />
                    <Building2 className="h-4 w-4" />
                    <span className="font-medium text-sm">{t("smallBusiness")}</span>
                  </div>
                  <p className="text-xs text-muted-foreground ml-6">Shop, firm, freelancer w/ GST</p>
                </Label>
              </RadioGroup>
            </div>

            <Separator />

            {/* Basic */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Field label={t("fullName")} value={data.name} onChange={(v) => update("name", v)} required />
              {data.userType === "small_business" && (
                <Field label={t("businessName")} value={data.businessName || ""} onChange={(v) => update("businessName", v)} />
              )}
              <Field label={t("pan")} value={data.pan || ""} onChange={(v) => update("pan", v.toUpperCase())} placeholder="ABCDE1234F" maxLength={10} />
              <Field label={t("gstin")} value={data.gstin || ""} onChange={(v) => update("gstin", v.toUpperCase())} placeholder="22ABCDE1234F1Z5" maxLength={15} />
              <Field label={t("mobile")} value={data.mobile || ""} onChange={(v) => update("mobile", v)} placeholder="9876543210" />
              <Field label={t("email")} value={data.email || ""} onChange={(v) => update("email", v)} placeholder="you@example.com" type="email" />
              <Field label={t("aadhaar")} value={data.aadhaar || ""} onChange={(v) => update("aadhaar", v)} placeholder="XXXX" maxLength={4} />
              <div className="space-y-1.5">
                <Label className="text-xs">{t("state")}</Label>
                <Select value={data.state || ""} onValueChange={(v) => update("state", v)}>
                  <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                  <SelectContent>
                    {INDIAN_STATES.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Field label={t("address")} value={data.address || ""} onChange={(v) => update("address", v)} placeholder="Full address" />

            <Separator />

            {/* Tax regime preference */}
            <div className="space-y-2">
              <Label>{t("regime")} preference</Label>
              <RadioGroup
                value={data.regime}
                onValueChange={(v) => update("regime", v as any)}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="new" id="pr-new" />
                  <Label htmlFor="pr-new" className="cursor-pointer font-normal text-sm">{t("newRegime")} (default)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="old" id="pr-old" />
                  <Label htmlFor="pr-old" className="cursor-pointer font-normal text-sm">{t("oldRegime")}</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        )}

        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={onClose}>{t("cancel")}</Button>
          <Button onClick={handleSave} disabled={saving || loading}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {t("saveProfile")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label, value, onChange, placeholder, type = "text", maxLength, required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  maxLength?: number;
  required?: boolean;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <Input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        maxLength={maxLength}
      />
    </div>
  );
}
