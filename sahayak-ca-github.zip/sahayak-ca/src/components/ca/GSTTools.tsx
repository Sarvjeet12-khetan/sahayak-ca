"use client";

import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Info, Calculator, FileBarChart } from "lucide-react";
import { addGst, removeGst, computeGstr, formatINR } from "@/lib/indianTax";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

const GST_RATES = [0, 5, 12, 18, 28];

export function GSTTools() {
  const { t } = useI18n();
  const [tab, setTab] = useState<"calculator" | "gstr">("calculator");

  return (
    <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="w-full">
      <TabsList className="grid w-full max-w-md grid-cols-2 mb-4">
        <TabsTrigger value="calculator"><Calculator className="h-4 w-4 mr-1.5" />{t("gstCalculator")}</TabsTrigger>
        <TabsTrigger value="gstr"><FileBarChart className="h-4 w-4 mr-1.5" />{t("gstrSummary")}</TabsTrigger>
      </TabsList>
      <TabsContent value="calculator"><GstCalculator /></TabsContent>
      <TabsContent value="gstr"><GstrSummary /></TabsContent>
    </Tabs>
  );
}

function GstCalculator() {
  const { t } = useI18n();
  const [amount, setAmount] = useState<string>("1000");
  const [rate, setRate] = useState<number>(18);
  const [mode, setMode] = useState<"add" | "remove">("add");
  const [interState, setInterState] = useState<boolean>(false);

  const amt = parseFloat(amount) || 0;
  const result = mode === "add" ? addGst(amt, rate, interState) : removeGst(amt, rate, interState);

  return (
    <div className="space-y-4">
      <Card className="paper-card">
        <CardHeader>
          <CardTitle className="font-serif">{t("gstCalculator")}</CardTitle>
          <CardDescription>{t("gstCalcDesc")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="gst-amount">{t("gstAmount")}</Label>
              <Input
                id="gst-amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="1000"
              />
            </div>
            <div className="space-y-2">
              <Label>{t("gstRate")}</Label>
              <Select value={String(rate)} onValueChange={(v) => setRate(Number(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {GST_RATES.map((r) => (
                    <SelectItem key={r} value={String(r)}>{r}%</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t("transactionType")}</Label>
            <RadioGroup
              value={mode}
              onValueChange={(v) => setMode(v as any)}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="add" id="add" />
                <Label htmlFor="add" className="cursor-pointer font-normal text-sm">{t("addGst")}</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="remove" id="remove" />
                <Label htmlFor="remove" className="cursor-pointer font-normal text-sm">{t("removeGst")}</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>{t("intraState")} / {t("interState")}</Label>
            <RadioGroup
              value={interState ? "inter" : "intra"}
              onValueChange={(v) => setInterState(v === "inter")}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="intra" id="intra" />
                <Label htmlFor="intra" className="cursor-pointer font-normal text-sm">{t("intraState")}</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="inter" id="inter" />
                <Label htmlFor="inter" className="cursor-pointer font-normal text-sm">{t("interState")}</Label>
              </div>
            </RadioGroup>
          </div>

          <Separator />

          {/* Result */}
          <div className="rounded-lg border border-border bg-muted/30 p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t("baseAmount")}</span>
              <span className="font-medium">{formatINR(result.baseAmount)}</span>
            </div>
            {interState ? (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{t("igst")} ({rate}%)</span>
                <span className="font-medium">{formatINR(result.igst)}</span>
              </div>
            ) : (
              <>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("cgst")} ({rate / 2}%)</span>
                  <span className="font-medium">{formatINR(result.cgst)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{t("sgst")} ({rate / 2}%)</span>
                  <span className="font-medium">{formatINR(result.sgst)}</span>
                </div>
              </>
            )}
            <Separator />
            <div className="flex justify-between text-base font-bold">
              <span>{mode === "add" ? t("totalWithGst") : t("amountWithoutGst")}</span>
              <span className="text-primary">{formatINR(result.total)}</span>
            </div>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Heads up</AlertTitle>
            <AlertDescription className="text-xs">{t("gstNote")}</AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}

function GstrSummary() {
  const { t } = useI18n();
  const [sales5, setSales5] = useState<string>("0");
  const [sales12, setSales12] = useState<string>("0");
  const [sales18, setSales18] = useState<string>("0");
  const [sales28, setSales28] = useState<string>("0");
  const [sales0, setSales0] = useState<string>("0");

  const result = computeGstr({
    sales5: parseFloat(sales5) || 0,
    sales12: parseFloat(sales12) || 0,
    sales18: parseFloat(sales18) || 0,
    sales28: parseFloat(sales28) || 0,
    sales0: parseFloat(sales0) || 0,
  });

  const handlePrint = () => window.print();

  return (
    <Card className="paper-card">
      <CardHeader>
        <CardTitle className="font-serif">{t("gstrSummary")}</CardTitle>
        <CardDescription>{t("gstrDesc")}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <SalesInput label={t("sales5")} value={sales5} onChange={setSales5} />
          <SalesInput label={t("sales12")} value={sales12} onChange={setSales12} />
          <SalesInput label={t("sales18")} value={sales18} onChange={setSales18} />
          <SalesInput label={t("sales28")} value={sales28} onChange={setSales28} />
          <SalesInput label={t("sales0")} value={sales0} onChange={setSales0} />
        </div>

        <Separator />

        {/* Summary table */}
        <div className="rounded-lg border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left px-3 py-2 font-medium">GST Rate</th>
                <th className="text-right px-3 py-2 font-medium">{t("baseAmount")}</th>
                <th className="text-right px-3 py-2 font-medium">{t("totalTax")}</th>
                <th className="text-right px-3 py-2 font-medium">{t("total")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {result.breakdown.map((b) => (
                <tr key={b.rate}>
                  <td className="px-3 py-2">{b.rate}%</td>
                  <td className="px-3 py-2 text-right">{formatINR(b.base)}</td>
                  <td className="px-3 py-2 text-right">{formatINR(b.tax)}</td>
                  <td className="px-3 py-2 text-right font-medium">{formatINR(b.total)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-primary/5 font-bold">
              <tr>
                <td className="px-3 py-2">{t("totalSales")}</td>
                <td className="px-3 py-2 text-right">{formatINR(result.totalSales)}</td>
                <td className="px-3 py-2 text-right text-primary">{formatINR(result.totalTax)}</td>
                <td className="px-3 py-2 text-right">{formatINR(result.totalSales + result.totalTax)}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="text-sm space-y-1">
            <p><span className="text-muted-foreground">{t("totalSales")}: </span><span className="font-semibold">{formatINR(result.totalSales)}</span></p>
            <p><span className="text-muted-foreground">{t("totalTaxCollected")}: </span><span className="font-semibold text-primary">{formatINR(result.totalTax)}</span></p>
          </div>
          <Button variant="outline" onClick={handlePrint} className="print:hidden">
            <FileBarChart className="h-4 w-4 mr-2" />
            {t("print")}
          </Button>
        </div>

        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription className="text-xs">{t("gstNote")}</AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}

function SalesInput({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      <Input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="0"
      />
    </div>
  );
}
