"use client";

import { useI18n, LANGUAGE_LABELS, type Language } from "@/lib/i18n";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Globe, User, ChevronDown } from "lucide-react";

interface HeaderProps {
  onOpenProfile: () => void;
  profileName?: string | null;
}

export function Header({ onOpenProfile, profileName }: HeaderProps) {
  const { language, setLanguage, t } = useI18n();

  return (
    <header className="bg-primary text-primary-foreground shadow-md">
      {/* Tricolor accent bar */}
      <div className="gov-tricolor h-1 w-full" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3 min-w-0">
          {/* Emblem-style circular logo */}
          <div className="hidden sm:flex h-11 w-11 items-center justify-center rounded-full bg-primary-foreground/10 ring-2 ring-primary-foreground/30 shrink-0">
            <span className="font-serif text-xl font-bold tracking-tight">CA</span>
          </div>
          <div className="min-w-0">
            <h1 className="font-serif text-lg sm:text-xl font-bold leading-tight truncate">
              {t("appName")}
            </h1>
            <p className="text-[11px] sm:text-xs text-primary-foreground/80 leading-tight truncate">
              {t("appSubtitle")}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Language switcher */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="secondary"
                size="sm"
                className="bg-primary-foreground/10 hover:bg-primary-foreground/20 text-primary-foreground border border-primary-foreground/20"
              >
                <Globe className="h-4 w-4" />
                <span className="hidden sm:inline">{LANGUAGE_LABELS[language].native}</span>
                <span className="sm:hidden">{LANGUAGE_LABELS[language].code}</span>
                <ChevronDown className="h-3 w-3 opacity-70" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              {(Object.keys(LANGUAGE_LABELS) as Language[]).map((lang) => (
                <DropdownMenuItem
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className="flex items-center justify-between cursor-pointer"
                >
                  <span>{LANGUAGE_LABELS[lang].native}</span>
                  {language === lang && (
                    <Badge variant="outline" className="text-[10px] py-0 px-1">✓</Badge>
                  )}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Profile */}
          <Button
            variant="secondary"
            size="sm"
            onClick={onOpenProfile}
            className="bg-primary-foreground/10 hover:bg-primary-foreground/20 text-primary-foreground border border-primary-foreground/20"
          >
            <Avatar className="h-6 w-6 mr-1">
              <AvatarFallback className="bg-primary-foreground text-primary text-xs font-bold">
                {profileName ? profileName.charAt(0).toUpperCase() : <User className="h-3 w-3" />}
              </AvatarFallback>
            </Avatar>
            <span className="hidden sm:inline max-w-[120px] truncate">
              {profileName || t("navProfile")}
            </span>
          </Button>
        </div>
      </div>
    </header>
  );
}
