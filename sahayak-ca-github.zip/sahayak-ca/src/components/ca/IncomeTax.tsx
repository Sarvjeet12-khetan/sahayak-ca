"use client";

import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Tabs, TabsList, TabsTrigger, TabsContent,
} from "@/components/ui/tabs";
import { Info, Calculator, CalendarClock, ArrowRightCircle } from "lucide-react";
import {
  computeIncomeTax, computeAdvanceTax,
  formatINR, NEW_REGIME_SLABS, OLD_REGIME_SLABS,
  type IncomeTaxInput,
} from "@/lib/indianTax";

export function IncomeTax() {
  const { t } = useI18n();
  const [tab, setTab] = useState<"calculator" | "advance">("calculator");
  const [regime, setRegime] = useState<"new" | "old">("new");
  const [salaryIncome, setSalaryIncome] = useState<string>("1000000");
  const [otherIncome, setOtherIncome] = useState<string>("0");
  const [d80C, setD80C] = useState<string>("0");
  const [d80D, setD80D] = useState<string>("0");
  const [d80G, setD80G] = useState<string>("0");
  const [dHra, setDHra] = useState<string>("0");
  const [dHome, setDHome] = useState<string>("0");

  const input: IncomeTaxInput = {
    regime,
    salaryIncome: parseFloat(salaryIncome) || 0,
    otherIncome: parseFloat(otherIncome) || 0,
    deduction80C: parseFloat(d80C) || 0,
    deduction80D: parseFloat(d80D) || 0,
    deduction80G: parseFloat(d80G) || 0,
    deductionHRA: parseFloat(dHra) || 0,
    deductionHome: parseFloat(dHome) || 0,
  };

  const result = computeIncomeTax(input);

  // Compare both regimes
  const newResult = computeIncomeTax({ ...input, regime: "new" });
  const oldResult = computeIncomeTax({ ...input, regime: "old" });
  const bestRegime: "new" | "old" = newResult.totalTax <= oldResult.totalTax ? "new" : "old";
  const savings = Math.abs(newResult.totalTax - oldResult.totalTax);

  const advanceInstallments = computeAdvanceTax(result.totalTax);
  const slabs = regime === "new" ? NEW_REGIME_SLABS : OLD_REGIME_SLABS;

  return (
    <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="w-full">
      <TabsList className="grid w-full max-w-md grid-cols-2 mb-4">
        <TabsTrigger value="calculator"><Calculator className="h-4 w-4 mr-1.5" />{t("itCalc")}</TabsTrigger>
        <TabsTrigger value="advance"><CalendarClock className="h-4 w-4 mr-1.5" />{t("advanceTax")}</TabsTrigger>
      </TabsList>

      <TabsContent value="calculator">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          {/* Inputs — 3 cols */}
          <Card className="paper-card lg:col-span-3">
            <CardHeader>
              <CardTitle className="font-serif">{t("itCalc")}</CardTitle>
              <CardDescription>{t("itCalcDesc")}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>{t("regime")}</Label>
                <RadioGroup
                  value={regime}
                  onValueChange={(v) => setRegime(v as any)}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="new" id="reg-new" />
                    <Label htmlFor="reg-new" className="cursor-pointer font-normal text-sm">{t("newRegime")}</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="old" id="reg-old" />
                    <Label htmlFor="reg-old" className="cursor-pointer font-normal text-sm">{t("oldRegime")}</Label>
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label={t("salaryIncome")} value={salaryIncome} onChange={setSalaryIncome} placeholder="1000000" />
                <Field label={t("otherIncome")} value={otherIncome} onChange={setOtherIncome} placeholder="0" />
              </div>

              {regime === "old" && (
                <>
                  <div className="pt-2">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t("deductions")}</p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Field label={t("deduction80C")} value={d80C} onChange={setD80C} placeholder="150000" />
                    <Field label={t("deduction80D")} value={d80D} onChange={setD80D} placeholder="25000" />
                    <Field label={t("deduction80G")} value={d80G} onChange={setD80G} placeholder="0" />
                    <Field label={t("deductionHRA")} value={dHra} onChange={setDHra} placeholder="0" />
                    <Field label={t("deductionHome")} value={dHome} onChange={setDHome} placeholder="0" />
                  </div>
                </>
              )}
              {regime === "new" && (
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    New regime includes a {t("stdDeduction")} of ₹75,000 automatically. Most other deductions (80C, 80D, HRA) are not allowed under new regime.
                  </AlertDescription>
                </Alert>
              )}

              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Regime comparison</AlertTitle>
                <AlertDescription className="text-xs">
                  {bestRegime === "new" ? t("newRegimeBenefit") : t("oldRegimeBenefit")} <span className="font-semibold">{formatINR(savings)}</span> {t("saveBySwitching")}
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Result — 2 cols */}
          <Card className="paper-card lg:col-span-2 self-start">
            <CardHeader>
              <CardTitle className="font-serif text-base flex items-center gap-2">
                <ArrowRightCircle className="h-4 w-4 text-primary" />
                Result
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Row label={t("annualIncome")} value={formatINR(result.grossIncome)} />
              <Row label={t("deductions")} value={`– ${formatINR(result.totalDeductions)}`} muted />
              <Separator />
              <Row label={t("taxableIncome")} value={formatINR(result.taxableIncome)} bold />
              <Row label={t("taxBeforeCess")} value={formatINR(result.taxBeforeCess)} />
              {result.rebate > 0 && (
                <Row label={t("rebate87A")} value={`– ${formatINR(result.rebate)}`} muted success />
              )}
              <Row label={t("cess")} value={`+ ${formatINR(result.cess)}`} muted />
              <Separator />
              <div className="rounded-md bg-primary/10 p-3">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-medium">{t("totalTax")}</span>
                  <span className="font-serif text-2xl font-bold text-primary">{formatINR(result.totalTax)}</span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>{t("effectiveRate")}: {result.effectiveRate.toFixed(2)}%</span>
                  <span>{t("monthlyTax")}: {formatINR(result.monthlyTax)}</span>
                </div>
              </div>

              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 mt-2">
                  Tax Slabs ({regime === "new" ? t("newRegime") : t("oldRegime")})
                </p>
                <ul className="text-xs space-y-1 ca-scroll max-h-40 overflow-y-auto">
                  {slabs.map((s, i) => {
                    const prev = i === 0 ? 0 : slabs[i - 1].upTo;
                    const label = s.upTo === Infinity ? `Above ${formatINR(prev)}` : `${formatINR(prev)} – ${formatINR(s.upTo)}`;
                    return (
                      <li key={i} className="flex justify-between">
                        <span className="text-muted-foreground">{label}</span>
                        <Badge variant="outline" className="text-[10px] py-0">{(s.rate * 100).toFixed(0)}%</Badge>
                      </li>
                    );
                  })}
                </ul>
              </div>

              <p className="text-[10px] text-muted-foreground italic mt-2">{t("itDisclaimer")}</p>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="advance">
        <Card className="paper-card">
          <CardHeader>
            <CardTitle className="font-serif">{t("advanceTax")}</CardTitle>
            <CardDescription>{t("advanceTaxDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-md bg-muted/30 p-3 text-sm">
              <p><span className="text-muted-foreground">{t("totalTax")} (current regime): </span><span className="font-bold text-primary">{formatINR(result.totalTax)}</span></p>
              {result.totalTax <= 10000 ? (
                <p className="text-xs text-muted-foreground mt-1">Below ₹10,000 → No advance tax required. Pay full tax at year-end (self-assessment).</p>
              ) : (
                <p className="text-xs text-muted-foreground mt-1">Advance tax is mandatory. Pay in 4 installments:</p>
              )}
            </div>

            {advanceInstallments.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {advanceInstallments.map((inst, i) => (
                  <Card key={i} className="paper-card">
                    <CardContent className="p-4">
                      <p className="text-xs text-muted-foreground">{inst.label}</p>
                      <p className="font-serif text-lg font-bold mt-1">{inst.dueDate}</p>
                      <Separator className="my-2" />
                      <p className="text-xs text-muted-foreground">{inst.percent}% of annual tax</p>
                      <p className="text-base font-semibold text-primary mt-0.5">{formatINR(inst.amount)}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription className="text-xs">
                  Estimated annual tax is below ₹10,000. Advance tax is not applicable. You may pay via self-assessment tax before filing ITR.
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>How to pay</AlertTitle>
              <AlertDescription className="text-xs">
                Pay advance tax via <span className="font-medium">ITNS 280</span> on <span className="font-medium">tin.tin.nsdl.com</span> or the Income Tax e-filing portal. Use your PAN. Select "Advance Tax (100)" under Type of Payment.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      <Input type="number" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  );
}

function Row({ label, value, muted, bold, success }: { label: string; value: string; muted?: boolean; bold?: boolean; success?: boolean }) {
  return (
    <div className="flex justify-between items-baseline text-sm">
      <span className={muted ? "text-muted-foreground" : ""}>{label}</span>
      <span className={`${bold ? "font-bold text-foreground" : ""} ${success ? "text-emerald-700" : muted ? "text-muted-foreground" : ""} ${!bold && !muted ? "font-medium" : ""}`}>
        {value}
      </span>
    </div>
  );
}
