"use client";

import { useI18n } from "@/lib/i18n";
import { ShieldCheck, Info } from "lucide-react";

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="mt-auto border-t border-border bg-muted/20 print:hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 space-y-2">
        <div className="flex items-start gap-2 text-xs text-muted-foreground">
          <Info className="h-3.5 w-3.5 mt-0.5 shrink-0" />
          <p>{t("footerNote")}</p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" />
          <p className="text-muted-foreground">{t("footerDisclaimer")}</p>
        </div>
        <div className="pt-2 border-t border-border/50 text-[10px] text-muted-foreground">
          Sahayak CA · FY 2025-26 (AY 2026-27) · {new Date().getFullYear()}
        </div>
      </div>
    </footer>
  );
}
