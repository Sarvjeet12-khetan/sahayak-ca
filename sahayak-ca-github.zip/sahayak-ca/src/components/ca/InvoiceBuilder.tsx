"use client";

import { useState, useEffect, useMemo } from "react";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from "@/components/ui/table";
import { Plus, Trash2, Save, FileText, Printer, Info, Building2 } from "lucide-react";
import { addGst, formatINR, SAMPLE_HSN_CODES, INDIAN_STATES, formatDateIST } from "@/lib/indianTax";
import type { InvoiceItemInput, ProfileData } from "./types";
import { toast } from "sonner";

interface InvoiceBuilderProps {
  profile?: ProfileData | null;
  onSaved?: () => void;
}

interface SavedInvoice {
  id: string;
  invoiceNumber: string;
  invoiceDate: string;
  customerName: string;
  grandTotal: number;
}

export function InvoiceBuilder({ profile, onSaved }: InvoiceBuilderProps) {
  const { t } = useI18n();
  const today = new Date().toISOString().slice(0, 10);
  const [invoiceNumber, setInvoiceNumber] = useState<string>(`INV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`);
  const [invoiceDate, setInvoiceDate] = useState<string>(today);
  const [customerName, setCustomerName] = useState<string>("");
  const [customerGstin, setCustomerGstin] = useState<string>("");
  const [customerState, setCustomerState] = useState<string>("");
  const [placeOfSupply, setPlaceOfSupply] = useState<string>(profile?.state || "");
  const [interState, setInterState] = useState<boolean>(false);
  const [notes, setNotes] = useState<string>("");
  const [items, setItems] = useState<InvoiceItemInput[]>([
    { description: "", hsn: "", quantity: 1, rate: 0, gstRate: 18, amount: 0, cgst: 0, sgst: 0, igst: 0, taxAmount: 0, total: 0 },
  ]);
  const [savedInvoices, setSavedInvoices] = useState<SavedInvoice[]>([]);
  const [saving, setSaving] = useState(false);

  // Load saved invoices
  const loadInvoices = async () => {
    try {
      const res = await fetch("/api/invoices");
      const data = await res.json();
      setSavedInvoices((data.invoices || []).map((i: any) => ({
        id: i.id,
        invoiceNumber: i.invoiceNumber,
        invoiceDate: i.invoiceDate,
        customerName: i.customerName,
        grandTotal: i.grandTotal,
      })));
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  // Auto-detect inter-state if customer state differs from seller state
  useEffect(() => {
    if (customerState && profile?.state) {
      setInterState(customerState !== profile.state);
    }
  }, [customerState, profile?.state]);

  const computedItems = useMemo(() => {
    return items.map((it) => {
      const amount = (Number(it.quantity) || 0) * (Number(it.rate) || 0);
      const gst = addGst(amount, Number(it.gstRate) || 0, interState);
      return {
        ...it,
        amount,
        cgst: gst.cgst,
        sgst: gst.sgst,
        igst: gst.igst,
        taxAmount: gst.gstAmount,
        total: gst.total,
      };
    });
  }, [items, interState]);

  const totals = useMemo(() => {
    return computedItems.reduce(
      (acc, it) => ({
        amount: acc.amount + it.amount,
        cgst: acc.cgst + it.cgst,
        sgst: acc.sgst + it.sgst,
        igst: acc.igst + it.igst,
        tax: acc.tax + it.taxAmount,
        grand: acc.grand + it.total,
      }),
      { amount: 0, cgst: 0, sgst: 0, igst: 0, tax: 0, grand: 0 }
    );
  }, [computedItems]);

  const updateItem = (index: number, field: keyof InvoiceItemInput, value: any) => {
    setItems((prev) => prev.map((it, i) => (i === index ? { ...it, [field]: value } : it)));
  };

  const addItem = () => {
    setItems((prev) => [
      ...prev,
      { description: "", hsn: "", quantity: 1, rate: 0, gstRate: 18, amount: 0, cgst: 0, sgst: 0, igst: 0, taxAmount: 0, total: 0 },
    ]);
  };

  const removeItem = (index: number) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!customerName.trim()) {
      toast.error("Please enter customer name");
      return;
    }
    if (computedItems.length === 0 || computedItems.every((i) => !i.description.trim())) {
      toast.error("Add at least one item");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          invoiceNumber,
          invoiceDate,
          customerName,
          customerGstin: customerGstin || null,
          customerState: customerState || null,
          placeOfSupply: placeOfSupply || null,
          isInterState: interState,
          items: computedItems.filter((i) => i.description.trim()),
          totalAmount: totals.amount,
          totalCgst: totals.cgst,
          totalSgst: totals.sgst,
          totalIgst: totals.igst,
          totalTax: totals.tax,
          grandTotal: totals.grand,
          notes: notes || null,
          status: "issued",
        }),
      });
      if (!res.ok) throw new Error("Save failed");
      toast.success(t("saved"));
      await loadInvoices();
      onSaved?.();
    } catch (e) {
      toast.error("Failed to save invoice");
    } finally {
      setSaving(false);
    }
  };

  const handlePrint = () => window.print();

  return (
    <div className="space-y-4">
      <Card className="paper-card">
        <CardHeader>
          <CardTitle className="font-serif flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            {t("invoiceBuilder")}
          </CardTitle>
          <CardDescription>{t("invoiceDesc")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Invoice meta */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">{t("invoiceNo")}</Label>
              <Input value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">{t("invoiceDate")}</Label>
              <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">{t("placeOfSupply")}</Label>
              <Select value={placeOfSupply} onValueChange={setPlaceOfSupply}>
                <SelectTrigger><SelectValue placeholder="Select state" /></SelectTrigger>
                <SelectContent>
                  {INDIAN_STATES.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          {/* Bill From / Bill To */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-md border border-border bg-muted/20 p-3 space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground flex items-center gap-1.5">
                <Building2 className="h-3 w-3" /> {t("billFrom")}
              </p>
              <div className="text-sm">
                <p className="font-medium">{profile?.businessName || profile?.name || "—"}</p>
                {profile?.address && <p className="text-muted-foreground text-xs">{profile.address}</p>}
                {profile?.state && <p className="text-muted-foreground text-xs">{profile.state}</p>}
                {profile?.gstin && <p className="text-xs mt-1"><span className="text-muted-foreground">GSTIN: </span><span className="font-medium">{profile.gstin}</span></p>}
                {profile?.pan && <p className="text-xs"><span className="text-muted-foreground">PAN: </span><span className="font-medium">{profile.pan}</span></p>}
              </div>
            </div>
            <div className="rounded-md border border-border p-3 space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{t("billTo")}</p>
              <div className="space-y-2">
                <Input placeholder={t("customerName")} value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
                <Input placeholder={t("customerGstin") + " (optional)"} value={customerGstin} onChange={(e) => setCustomerGstin(e.target.value)} />
                <Select value={customerState} onValueChange={setCustomerState}>
                  <SelectTrigger><SelectValue placeholder="Customer State" /></SelectTrigger>
                  <SelectContent>
                    {INDIAN_STATES.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="interstate"
              checked={interState}
              onCheckedChange={(v) => setInterState(!!v)}
            />
            <Label htmlFor="interstate" className="text-sm font-normal cursor-pointer">
              {interState ? t("interState") + " — IGST will apply" : t("intraState") + " — CGST + SGST will apply"}
            </Label>
          </div>

          <Separator />

          {/* Items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-semibold">{t("items")}</p>
              <Button size="sm" variant="outline" onClick={addItem}>
                <Plus className="h-4 w-4 mr-1" />{t("addItem")}
              </Button>
            </div>
            <div className="overflow-x-auto rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40">
                    <TableHead className="min-w-[160px]">{t("description")}</TableHead>
                    <TableHead className="min-w-[110px]">{t("hsn")}</TableHead>
                    <TableHead className="w-16">{t("qty")}</TableHead>
                    <TableHead className="w-28">{t("unitRate")}</TableHead>
                    <TableHead className="w-20">{t("itemGstRate")}</TableHead>
                    <TableHead className="w-28 text-right">{t("amount")}</TableHead>
                    <TableHead className="w-28 text-right">{t("totalTax")}</TableHead>
                    <TableHead className="w-28 text-right">{t("total")}</TableHead>
                    <TableHead className="w-10 print:hidden"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {computedItems.map((it, i) => (
                    <TableRow key={i}>
                      <TableCell>
                        <Input
                          value={it.description}
                          onChange={(e) => updateItem(i, "description", e.target.value)}
                          placeholder="Item description"
                          className="h-8 text-sm"
                        />
                      </TableCell>
                      <TableCell>
                        <Select value={it.hsn} onValueChange={(v) => updateItem(i, "hsn", v)}>
                          <SelectTrigger className="h-8 text-sm"><SelectValue placeholder="HSN/SAC" /></SelectTrigger>
                          <SelectContent>
                            {SAMPLE_HSN_CODES.map((c) => (
                              <SelectItem key={c.code} value={c.code}>
                                {c.code} — {c.desc} ({c.rate}%)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={it.quantity}
                          onChange={(e) => updateItem(i, "quantity", Number(e.target.value))}
                          className="h-8 text-sm w-16"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={it.rate}
                          onChange={(e) => updateItem(i, "rate", Number(e.target.value))}
                          className="h-8 text-sm w-28"
                        />
                      </TableCell>
                      <TableCell>
                        <Select value={String(it.gstRate)} onValueChange={(v) => {
                          updateItem(i, "gstRate", Number(v));
                          // also update HSN default rate
                          const found = SAMPLE_HSN_CODES.find((c) => c.code === it.hsn);
                          if (found) updateItem(i, "gstRate", found.rate);
                        }}>
                          <SelectTrigger className="h-8 text-sm w-20"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {[0, 5, 12, 18, 28].map((r) => (
                              <SelectItem key={r} value={String(r)}>{r}%</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-right text-sm">{formatINR(it.amount)}</TableCell>
                      <TableCell className="text-right text-sm text-muted-foreground">{formatINR(it.taxAmount)}</TableCell>
                      <TableCell className="text-right text-sm font-medium">{formatINR(it.total)}</TableCell>
                      <TableCell className="print:hidden">
                        <Button variant="ghost" size="sm" onClick={() => removeItem(i)} className="h-7 w-7 p-0 text-destructive">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <Label className="text-xs">Notes / Terms (optional)</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Payment terms, bank details, etc." />
          </div>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-full sm:w-72 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("subtotal")}</span>
                <span>{formatINR(totals.amount)}</span>
              </div>
              {interState ? (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t("igst")}</span>
                  <span>{formatINR(totals.igst)}</span>
                </div>
              ) : (
                <>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("cgst")}</span>
                    <span>{formatINR(totals.cgst)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("sgst")}</span>
                    <span>{formatINR(totals.sgst)}</span>
                  </div>
                </>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("totalTax")}</span>
                <span>{formatINR(totals.tax)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-base">
                <span>{t("grandTotal")}</span>
                <span className="text-primary">{formatINR(totals.grand)}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 print:hidden">
            <Button onClick={handleSave} disabled={saving}>
              <Save className="h-4 w-4 mr-2" />
              {saving ? t("loading") : t("saveInvoice")}
            </Button>
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-2" />
              {t("print")}
            </Button>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Tip: When you select an HSN/SAC code, the GST rate is suggested automatically. Confirm it matches your goods/services.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Saved invoices */}
      <Card className="paper-card print:hidden">
        <CardHeader>
          <CardTitle className="font-serif text-base">{t("savedInvoices")}</CardTitle>
        </CardHeader>
        <CardContent>
          {savedInvoices.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">{t("noInvoices")}</p>
          ) : (
            <div className="ca-scroll max-h-72 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("invoiceNo")}</TableHead>
                    <TableHead>{t("date")}</TableHead>
                    <TableHead>{t("customerName")}</TableHead>
                    <TableHead className="text-right">{t("grandTotal")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {savedInvoices.map((inv) => (
                    <TableRow key={inv.id}>
                      <TableCell className="font-medium">{inv.invoiceNumber}</TableCell>
                      <TableCell>{formatDateIST(new Date(inv.invoiceDate))}</TableCell>
                      <TableCell>{inv.customerName}</TableCell>
                      <TableCell className="text-right">{formatINR(inv.grandTotal)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
