"use client";

import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Receipt, Calculator, FileText, BookOpen, Bot, BellRing,
  ArrowRight, TrendingUp, Wallet, IndianRupee, Clock,
} from "lucide-react";
import { formatINR, formatDateIST, COMPLIANCE_DATES } from "@/lib/indianTax";
import type { TabKey } from "@/components/ca/types";

interface DashboardProps {
  onNavigate: (tab: TabKey) => void;
  profileName?: string | null;
  invoiceCount: number;
  taxLiability?: number | null;
  gstPayable?: number | null;
  netCash?: number | null;
  customReminders: Array<{ id: string; title: string; dueDate: string; status: string }>;
}

export function Dashboard({
  onNavigate,
  profileName,
  invoiceCount,
  taxLiability,
  gstPayable,
  netCash,
  customReminders,
}: DashboardProps) {
  const { t } = useI18n();

  const quickActions: { tab: TabKey; icon: typeof Receipt; title: string; desc: string; color: string }[] = [
    { tab: "gst", icon: Receipt, title: t("navGst"), desc: t("gstCalculator"), color: "text-blue-700" },
    { tab: "incometax", icon: Calculator, title: t("navIncomeTax"), desc: t("itCalc"), color: "text-emerald-700" },
    { tab: "invoices", icon: FileText, title: t("navInvoices"), desc: t("invoiceBuilder"), color: "text-purple-700" },
    { tab: "books", icon: BookOpen, title: t("navBooks"), desc: t("books"), color: "text-orange-700" },
    { tab: "advisor", icon: Bot, title: t("navAdvisor"), desc: t("advisorTitle"), color: "text-rose-700" },
    { tab: "reminders", icon: BellRing, title: t("navReminders"), desc: t("remindersTitle"), color: "text-amber-700" },
  ];

  // Next 3 official compliance dates
  const today = new Date();
  const upcoming = COMPLIANCE_DATES
    .map((d) => ({ ...d, next: d.getNextDate(today) }))
    .sort((a, b) => a.next.getTime() - b.next.getTime())
    .slice(0, 3);

  // All upcoming reminders (custom + official)
  const allReminders = [
    ...customReminders.map((r) => ({
      title: r.title,
      date: new Date(r.dueDate),
      done: r.status === "done",
    })),
    ...upcoming.map((d) => ({
      title: d.title,
      date: d.next,
      done: false,
    })),
  ]
    .filter((r) => !r.done)
    .sort((a, b) => a.date.getTime() - b.date.getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <CardContent className="pt-6 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-primary">
                {t("welcome")}{profileName ? `, ${profileName.split(" ")[0]}` : ""}!
              </h2>
              <p className="text-muted-foreground mt-1 max-w-xl">{t("welcomeSub")}</p>
            </div>
            <div className="hidden sm:flex flex-col items-end gap-1 text-right">
              <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5">
                FY 2025-26 · AY 2026-27
              </Badge>
              <p className="text-xs text-muted-foreground">{formatDateIST(today)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Snapshot cards */}
      <div>
        <h3 className="font-serif text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          {t("yourSnapshot")}
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <SnapshotCard
            icon={FileText}
            label={t("invoicesThisMonth")}
            value={String(invoiceCount)}
            color="text-purple-700 bg-purple-50"
            onClick={() => onNavigate("invoices")}
          />
          <SnapshotCard
            icon={Calculator}
            label={t("taxLiability")}
            value={taxLiability != null ? formatINR(taxLiability) : "—"}
            color="text-emerald-700 bg-emerald-50"
            onClick={() => onNavigate("incometax")}
          />
          <SnapshotCard
            icon={IndianRupee}
            label={t("gstPayable")}
            value={gstPayable != null ? formatINR(gstPayable) : "—"}
            color="text-blue-700 bg-blue-50"
            onClick={() => onNavigate("gst")}
          />
          <SnapshotCard
            icon={Wallet}
            label={t("booksBalance")}
            value={netCash != null ? formatINR(netCash) : "—"}
            color="text-orange-700 bg-orange-50"
            onClick={() => onNavigate("books")}
          />
        </div>
      </div>

      {/* Quick actions */}
      <div>
        <h3 className="font-serif text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
          <ArrowRight className="h-5 w-5 text-primary" />
          {t("quickActions")}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickActions.map((a) => {
            const Icon = a.icon;
            return (
              <Card
                key={a.tab}
                className="paper-card hover:shadow-md hover:border-primary/40 transition-all cursor-pointer group"
                onClick={() => onNavigate(a.tab)}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className={`h-10 w-10 rounded-md flex items-center justify-center ${a.color} bg-opacity-10`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  <CardTitle className="font-serif text-base mt-2">{a.title}</CardTitle>
                  <CardDescription className="text-xs line-clamp-2">{a.desc}</CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Upcoming reminders */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-serif text-lg font-semibold text-foreground flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            {t("upcomingReminders")}
          </h3>
          <Button variant="ghost" size="sm" onClick={() => onNavigate("reminders")}>
            {t("viewAll")} <ArrowRight className="h-3 w-3 ml-1" />
          </Button>
        </div>
        <Card className="paper-card">
          <CardContent className="p-0">
            {allReminders.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">{t("noReminders")}</div>
            ) : (
              <ul className="divide-y divide-border ca-scroll max-h-72 overflow-y-auto">
                {allReminders.map((r, i) => {
                  const days = Math.ceil((r.date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                  const overdue = days < 0;
                  const today_ = days === 0;
                  return (
                    <li key={i} className="px-4 py-3 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{r.title}</p>
                        <p className="text-xs text-muted-foreground">{formatDateIST(r.date)}</p>
                      </div>
                      <Badge
                        variant={overdue ? "destructive" : today_ ? "default" : "secondary"}
                        className="text-[10px] whitespace-nowrap"
                      >
                        {overdue ? `${Math.abs(days)} ${t("overdue")}` : today_ ? t("dueToday") : `${days} ${t("daysAway")}`}
                      </Badge>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function SnapshotCard({
  icon: Icon,
  label,
  value,
  color,
  onClick,
}: {
  icon: typeof Receipt;
  label: string;
  value: string;
  color: string;
  onClick?: () => void;
}) {
  return (
    <Card
      className="paper-card hover:border-primary/40 transition-colors cursor-pointer"
      onClick={onClick}
    >
      <CardContent className="p-3 sm:p-4">
        <div className={`h-8 w-8 rounded-md flex items-center justify-center ${color} mb-2`}>
          <Icon className="h-4 w-4" />
        </div>
        <p className="text-[11px] sm:text-xs text-muted-foreground leading-tight">{label}</p>
        <p className="font-serif text-base sm:text-lg font-bold text-foreground mt-0.5 truncate">{value}</p>
      </CardContent>
    </Card>
  );
}
