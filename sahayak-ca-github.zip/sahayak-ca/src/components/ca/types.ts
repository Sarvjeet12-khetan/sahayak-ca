export type TabKey =
  | "dashboard"
  | "gst"
  | "incometax"
  | "invoices"
  | "books"
  | "advisor"
  | "reminders";

export interface InvoiceItemInput {
  description: string;
  hsn: string;
  quantity: number;
  rate: number;
  gstRate: number;
  amount: number;
  cgst: number;
  sgst: number;
  igst: number;
  taxAmount: number;
  total: number;
}

export interface TransactionInput {
  id?: string;
  date: string;
  type: "income" | "expense";
  category: string;
  description: string;
  amount: number;
  gstRate?: number | null;
  isGstRegistered?: boolean;
}

export interface ProfileData {
  name: string;
  pan?: string | null;
  gstin?: string | null;
  aadhaar?: string | null;
  mobile?: string | null;
  email?: string | null;
  address?: string | null;
  state?: string | null;
  userType: "individual" | "small_business";
  businessName?: string | null;
  regime: "new" | "old";
}
