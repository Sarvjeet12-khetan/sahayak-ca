"use client";

import { useState, useEffect, useMemo } from "react";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from "@/components/ui/table";
import { Plus, Trash2, ArrowDownCircle, ArrowUpCircle, BookOpen, TrendingUp, TrendingDown } from "lucide-react";
import { formatINR, formatDateIST } from "@/lib/indianTax";
import type { TransactionInput } from "./types";
import { toast } from "sonner";

interface Transaction extends TransactionInput {
  id: string;
}

const INCOME_CATEGORIES = ["Salary", "Sales", "Service Income", "Interest", "Rental", "Other"];
const EXPENSE_CATEGORIES = ["Rent", "Salaries", "Raw Material", "Utilities", "Travel", "Marketing", "Office Supplies", "Professional Fees", "Loan Payment", "Other"];

export function Bookkeeping() {
  const { t } = useI18n();
  const [tab, setTab] = useState<"entry" | "report">("entry");
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  // Entry form
  const today = new Date().toISOString().slice(0, 10);
  const [entryType, setEntryType] = useState<"income" | "expense">("expense");
  const [entryDate, setEntryDate] = useState<string>(today);
  const [entryCategory, setEntryCategory] = useState<string>("");
  const [entryDescription, setEntryDescription] = useState<string>("");
  const [entryAmount, setEntryAmount] = useState<string>("0");
  const [saving, setSaving] = useState(false);

  const loadTransactions = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/transactions");
      const data = await res.json();
      setTransactions((data.transactions || []).map((t: any) => ({
        id: t.id,
        date: new Date(t.date).toISOString().slice(0, 10),
        type: t.type,
        category: t.category,
        description: t.description,
        amount: t.amount,
      })));
    } catch (e) {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTransactions();
  }, []);

  const totals = useMemo(() => {
    const income = transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
    const expense = transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
    return { income, expense, net: income - expense };
  }, [transactions]);

  const handleAdd = async () => {
    if (!entryCategory) {
      toast.error("Please select a category");
      return;
    }
    if (!entryDescription.trim()) {
      toast.error("Please enter a description");
      return;
    }
    const amt = parseFloat(entryAmount);
    if (!amt || amt <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date: entryDate,
          type: entryType,
          category: entryCategory,
          description: entryDescription,
          amount: amt,
        }),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success(t("saved"));
      setEntryDescription("");
      setEntryAmount("0");
      await loadTransactions();
    } catch (e) {
      toast.error("Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/transactions?id=${id}`, { method: "DELETE" });
      setTransactions((prev) => prev.filter((t) => t.id !== id));
      toast.success("Deleted");
    } catch (e) {
      toast.error("Failed to delete");
    }
  };

  // Group transactions by category for P&L
  const grouped = useMemo(() => {
    const map = new Map<string, { income: number; expense: number }>();
    transactions.forEach((t) => {
      const cur = map.get(t.category) || { income: 0, expense: 0 };
      if (t.type === "income") cur.income += t.amount;
      else cur.expense += t.amount;
      map.set(t.category, cur);
    });
    return Array.from(map.entries()).map(([cat, v]) => ({ category: cat, ...v }));
  }, [transactions]);

  return (
    <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="w-full">
      <TabsList className="grid w-full max-w-md grid-cols-2 mb-4">
        <TabsTrigger value="entry"><Plus className="h-4 w-4 mr-1.5" />{t("addIncome")} / {t("addExpense")}</TabsTrigger>
        <TabsTrigger value="report"><BookOpen className="h-4 w-4 mr-1.5" />{t("profitLoss")}</TabsTrigger>
      </TabsList>

      <TabsContent value="entry" className="space-y-4">
        {/* Summary cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <SummaryCard icon={ArrowUpCircle} label={t("totalIncome")} value={formatINR(totals.income)} color="text-emerald-700 bg-emerald-50" />
          <SummaryCard icon={ArrowDownCircle} label={t("totalExpense")} value={formatINR(totals.expense)} color="text-rose-700 bg-rose-50" />
          <SummaryCard
            icon={totals.net >= 0 ? TrendingUp : TrendingDown}
            label={t("netProfit")}
            value={formatINR(totals.net)}
            color={totals.net >= 0 ? "text-emerald-700 bg-emerald-50" : "text-rose-700 bg-rose-50"}
          />
        </div>

        {/* Entry form */}
        <Card className="paper-card">
          <CardHeader>
            <CardTitle className="font-serif text-base flex items-center gap-2">
              <Plus className="h-4 w-4 text-primary" />
              {t("addIncome")} / {t("addExpense")}
            </CardTitle>
            <CardDescription>{t("booksDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">{t("category")}</Label>
                <Select value={entryType} onValueChange={(v) => { setEntryType(v as any); setEntryCategory(""); }}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="income">{t("income")}</SelectItem>
                    <SelectItem value="expense">{t("expense")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{t("date")}</Label>
                <Input type="date" value={entryDate} onChange={(e) => setEntryDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Sub-category</Label>
                <Select value={entryCategory} onValueChange={setEntryCategory}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {(entryType === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{t("description")}</Label>
                <Input value={entryDescription} onChange={(e) => setEntryDescription(e.target.value)} placeholder="Description" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{t("amount")} (₹)</Label>
                <div className="flex gap-1.5">
                  <Input type="number" value={entryAmount} onChange={(e) => setEntryAmount(e.target.value)} />
                  <Button onClick={handleAdd} disabled={saving} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent entries */}
        <Card className="paper-card">
          <CardHeader>
            <CardTitle className="font-serif text-base">{t("recentEntries")}</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-sm text-muted-foreground py-4 text-center">{t("loading")}</p>
            ) : transactions.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">{t("noEntries")}</p>
            ) : (
              <div className="ca-scroll max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("date")}</TableHead>
                      <TableHead>{t("category")}</TableHead>
                      <TableHead>{t("description")}</TableHead>
                      <TableHead className="text-right">{t("amount")}</TableHead>
                      <TableHead className="w-10 print:hidden"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((t) => (
                      <TableRow key={t.id}>
                        <TableCell className="text-xs">{formatDateIST(new Date(t.date))}</TableCell>
                        <TableCell><Badge variant="outline" className="text-[10px]">{t.category}</Badge></TableCell>
                        <TableCell className="text-sm">{t.description}</TableCell>
                        <TableCell className={`text-right text-sm font-medium ${t.type === "income" ? "text-emerald-700" : "text-rose-700"}`}>
                          {t.type === "income" ? "+" : "–"} {formatINR(t.amount)}
                        </TableCell>
                        <TableCell className="print:hidden">
                          <Button variant="ghost" size="sm" onClick={() => handleDelete(t.id)} className="h-7 w-7 p-0 text-destructive">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="report">
        <Card className="paper-card">
          <CardHeader>
            <CardTitle className="font-serif">{t("profitLoss")}</CardTitle>
            <CardDescription>{t("plPeriod")}: All recorded transactions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-md border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40">
                    <TableHead>{t("category")}</TableHead>
                    <TableHead className="text-right">{t("income")}</TableHead>
                    <TableHead className="text-right">{t("expense")}</TableHead>
                    <TableHead className="text-right">Net</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {grouped.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-6">
                        {t("noEntries")}
                      </TableCell>
                    </TableRow>
                  ) : (
                    grouped.map((g) => (
                      <TableRow key={g.category}>
                        <TableCell className="font-medium">{g.category}</TableCell>
                        <TableCell className="text-right text-emerald-700">{g.income > 0 ? formatINR(g.income) : "—"}</TableCell>
                        <TableCell className="text-right text-rose-700">{g.expense > 0 ? formatINR(g.expense) : "—"}</TableCell>
                        <TableCell className={`text-right font-medium ${g.income - g.expense >= 0 ? "text-emerald-700" : "text-rose-700"}`}>
                          {formatINR(g.income - g.expense)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
                <tfoot className="bg-primary/5 font-bold">
                  <TableRow>
                    <TableCell>{t("total")}</TableCell>
                    <TableCell className="text-right text-emerald-700">{formatINR(totals.income)}</TableCell>
                    <TableCell className="text-right text-rose-700">{formatINR(totals.expense)}</TableCell>
                    <TableCell className={`text-right ${totals.net >= 0 ? "text-emerald-700" : "text-rose-700"}`}>
                      {formatINR(totals.net)}
                    </TableCell>
                  </TableRow>
                </tfoot>
              </Table>
            </div>
            <Separator />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="rounded-md bg-emerald-50 border border-emerald-100 p-3">
                <p className="text-xs text-muted-foreground">{t("totalIncome")}</p>
                <p className="font-serif text-xl font-bold text-emerald-700">{formatINR(totals.income)}</p>
              </div>
              <div className="rounded-md bg-rose-50 border border-rose-100 p-3">
                <p className="text-xs text-muted-foreground">{t("totalExpense")}</p>
                <p className="font-serif text-xl font-bold text-rose-700">{formatINR(totals.expense)}</p>
              </div>
              <div className={`rounded-md p-3 border ${totals.net >= 0 ? "bg-emerald-50 border-emerald-100" : "bg-rose-50 border-rose-100"}`}>
                <p className="text-xs text-muted-foreground">{t("netProfit")}</p>
                <p className={`font-serif text-xl font-bold ${totals.net >= 0 ? "text-emerald-700" : "text-rose-700"}`}>
                  {formatINR(totals.net)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}

function SummaryCard({ icon: Icon, label, value, color }: { icon: typeof Plus; label: string; value: string; color: string }) {
  return (
    <Card className="paper-card">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`h-10 w-10 rounded-md flex items-center justify-center ${color}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground truncate">{label}</p>
          <p className="font-serif text-lg font-bold truncate">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
