"use client";

import { useI18n } from "@/lib/i18n";
import { type TabKey } from "./types";
import {
  LayoutDashboard, Receipt, Calculator, FileText, BookOpen, Bot, BellRing,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface TabNavProps {
  active: TabKey;
  onChange: (tab: TabKey) => void;
}

export function TabNav({ active, onChange }: TabNavProps) {
  const { t } = useI18n();

  const tabs: { key: TabKey; label: string; icon: typeof LayoutDashboard }[] = [
    { key: "dashboard", label: t("navDashboard"), icon: LayoutDashboard },
    { key: "gst", label: t("navGst"), icon: Receipt },
    { key: "incometax", label: t("navIncomeTax"), icon: Calculator },
    { key: "invoices", label: t("navInvoices"), icon: FileText },
    { key: "books", label: t("navBooks"), icon: BookOpen },
    { key: "advisor", label: t("navAdvisor"), icon: Bot },
    { key: "reminders", label: t("navReminders"), icon: BellRing },
  ];

  return (
    <>
      {/* Desktop horizontal nav */}
      <nav className="hidden md:block sticky top-0 z-30 bg-background/95 backdrop-blur border-b border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <ul className="flex gap-1 overflow-x-auto ca-scroll">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = active === tab.key;
              return (
                <li key={tab.key}>
                  <button
                    onClick={() => onChange(tab.key)}
                    className={cn(
                      "flex items-center gap-2 px-3 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap",
                      isActive
                        ? "border-primary text-primary"
                        : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {tab.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* Mobile bottom-fixed nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-background border-t border-border shadow-lg">
        <ul className="grid grid-cols-7">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = active === tab.key;
            return (
              <li key={tab.key}>
                <button
                  onClick={() => onChange(tab.key)}
                  className={cn(
                    "flex flex-col items-center justify-center gap-0.5 py-2 px-1 text-[9px] font-medium transition-colors",
                    isActive ? "text-primary" : "text-muted-foreground"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span className="truncate max-w-full leading-tight">{tab.label.split(" ")[0]}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}
