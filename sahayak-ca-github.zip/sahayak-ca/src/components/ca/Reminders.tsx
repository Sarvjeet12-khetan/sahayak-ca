"use client";

import { useState, useEffect, useMemo } from "react";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, BellRing, Calendar, CheckCircle2, Trash2, Info } from "lucide-react";
import { COMPLIANCE_DATES, formatDateIST } from "@/lib/indianTax";
import { toast } from "sonner";

interface CustomReminder {
  id: string;
  title: string;
  description?: string | null;
  dueDate: string;
  category: string;
  status: string;
}

const CATEGORY_COLORS: Record<string, string> = {
  gst: "bg-blue-50 text-blue-700 border-blue-200",
  income_tax: "bg-emerald-50 text-emerald-700 border-emerald-200",
  advance_tax: "bg-purple-50 text-purple-700 border-purple-200",
  itr: "bg-amber-50 text-amber-700 border-amber-200",
  other: "bg-muted text-muted-foreground border-border",
};

const CATEGORY_LABELS: Record<string, string> = {
  gst: "GST",
  income_tax: "Income Tax",
  advance_tax: "Advance Tax",
  itr: "ITR Filing",
  other: "Other",
};

export function Reminders() {
  const { t } = useI18n();
  const [reminders, setReminders] = useState<CustomReminder[]>([]);
  const [loading, setLoading] = useState(true);

  // New reminder form
  const today = new Date();
  const inSevenDays = new Date(today.getTime() + 7 * 86400000).toISOString().slice(0, 10);
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState(inSevenDays);
  const [category, setCategory] = useState("other");
  const [desc, setDesc] = useState("");

  const loadReminders = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/reminders");
      const data = await res.json();
      setReminders(data.reminders || []);
    } catch (e) {} finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReminders();
  }, []);

  const handleAdd = async () => {
    if (!title.trim()) {
      toast.error("Please enter a title");
      return;
    }
    try {
      const res = await fetch("/api/reminders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description: desc, dueDate, category, status: "pending" }),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success(t("saved"));
      setTitle("");
      setDesc("");
      await loadReminders();
    } catch (e) {
      toast.error("Failed to save");
    }
  };

  const handleMarkDone = async (id: string) => {
    try {
      await fetch("/api/reminders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: "done" }),
      });
      setReminders((prev) => prev.filter((r) => r.id !== id));
      toast.success("Marked done");
    } catch (e) {
      toast.error("Failed");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/reminders?id=${id}`, { method: "DELETE" });
      setReminders((prev) => prev.filter((r) => r.id !== id));
    } catch (e) {}
  };

  // Build sorted upcoming list (custom + official)
  const today_ = new Date();
  const upcoming = useMemo(() => {
    const items: {
      id: string;
      title: string;
      description?: string | null;
      date: Date;
      category: string;
      isCustom: boolean;
    }[] = [];

    reminders.forEach((r) => {
      items.push({
        id: r.id,
        title: r.title,
        description: r.description,
        date: new Date(r.dueDate),
        category: r.category,
        isCustom: true,
      });
    });

    COMPLIANCE_DATES.forEach((d) => {
      items.push({
        id: `official-${d.title}`,
        title: d.title,
        description: d.description,
        date: d.getNextDate(today_),
        category: d.category,
        isCustom: false,
      });
    });

    return items
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .slice(0, 12);
  }, [reminders]);

  return (
    <div className="space-y-4">
      <Card className="paper-card">
        <CardHeader>
          <CardTitle className="font-serif flex items-center gap-2">
            <BellRing className="h-5 w-5 text-primary" />
            {t("remindersTitle")}
          </CardTitle>
          <CardDescription>{t("remindersDesc")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Add new reminder */}
          <div className="rounded-md border border-border bg-muted/20 p-3 space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {t("addReminder")}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">{t("reminderTitle")}</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Pay Sep GSTR-3B" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{t("reminderDate")}</Label>
                <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{t("reminderCategory")}</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gst">GST</SelectItem>
                    <SelectItem value="income_tax">Income Tax</SelectItem>
                    <SelectItem value="advance_tax">Advance Tax</SelectItem>
                    <SelectItem value="itr">ITR Filing</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{t("reminderDesc")}</Label>
                <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Notes (optional)" />
              </div>
            </div>
            <Button onClick={handleAdd} size="sm">
              <Plus className="h-4 w-4 mr-1" />
              {t("addReminder")}
            </Button>
          </div>

          <Separator />

          {/* Upcoming list */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
              {t("upcomingReminders")}
            </p>
            {loading ? (
              <p className="text-sm text-muted-foreground py-4 text-center">{t("loading")}</p>
            ) : upcoming.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">{t("noCustomReminders")}</p>
            ) : (
              <ul className="space-y-2">
                {upcoming.map((r) => {
                  const days = Math.ceil((r.date.getTime() - today_.getTime()) / 86400000);
                  const overdue = days < 0;
                  const dueToday = days === 0;
                  const colorClass = CATEGORY_COLORS[r.category] || CATEGORY_COLORS.other;
                  return (
                    <li
                      key={r.id}
                      className="rounded-md border border-border bg-background p-3 flex items-start gap-3 hover:shadow-sm transition-shadow"
                    >
                      <div className={`h-10 w-10 rounded-md flex items-center justify-center ${colorClass} shrink-0`}>
                        <Calendar className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-medium truncate">{r.title}</p>
                          <Badge variant="outline" className={`text-[10px] py-0 ${colorClass}`}>
                            {CATEGORY_LABELS[r.category] || r.category}
                          </Badge>
                          {!r.isCustom && (
                            <Badge variant="secondary" className="text-[10px] py-0">{t("officialDates")}</Badge>
                          )}
                        </div>
                        {r.description && (
                          <p className="text-xs text-muted-foreground mt-0.5">{r.description}</p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatDateIST(r.date)}
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <Badge
                          variant={overdue ? "destructive" : dueToday ? "default" : "secondary"}
                          className="text-[10px]"
                        >
                          {overdue ? `${Math.abs(days)} ${t("overdue")}` : dueToday ? t("dueToday") : `${days} ${t("daysAway")}`}
                        </Badge>
                        {r.isCustom && (
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMarkDone(r.id)}
                              className="h-7 w-7 p-0 text-emerald-700"
                              title={t("markDone")}
                            >
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(r.id)}
                              className="h-7 w-7 p-0 text-destructive"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Official due dates are shown automatically based on current Indian tax calendar. Always confirm exact dates on the official GST / Income Tax portals, as they may be extended by notifications.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}
