import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    // Single-user app — return the first profile, or null
    const profile = await db.profile.findFirst({
      orderBy: { updatedAt: "desc" },
    });
    return NextResponse.json({ profile });
  } catch (err) {
    console.error("GET /api/profile error:", err);
    return NextResponse.json({ error: "Failed to load profile" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const existing = await db.profile.findFirst();
    let profile;
    if (existing) {
      profile = await db.profile.update({
        where: { id: existing.id },
        data: {
          name: body.name?.trim() || existing.name,
          pan: body.pan?.trim() || existing.pan,
          gstin: body.gstin?.trim() || existing.gstin,
          aadhaar: body.aadhaar?.trim() || existing.aadhaar,
          mobile: body.mobile?.trim() || existing.mobile,
          email: body.email?.trim() || existing.email,
          address: body.address?.trim() || existing.address,
          state: body.state?.trim() || existing.state,
          userType: body.userType || existing.userType,
          businessName: body.businessName?.trim() || existing.businessName,
          regime: body.regime || existing.regime,
        },
      });
    } else {
      profile = await db.profile.create({
        data: {
          name: body.name?.trim() || "User",
          pan: body.pan?.trim() || null,
          gstin: body.gstin?.trim() || null,
          aadhaar: body.aadhaar?.trim() || null,
          mobile: body.mobile?.trim() || null,
          email: body.email?.trim() || null,
          address: body.address?.trim() || null,
          state: body.state?.trim() || null,
          userType: body.userType || "individual",
          businessName: body.businessName?.trim() || null,
          regime: body.regime || "new",
        },
      });
    }
    return NextResponse.json({ profile });
  } catch (err) {
    console.error("POST /api/profile error:", err);
    return NextResponse.json({ error: "Failed to save profile" }, { status: 500 });
  }
}
