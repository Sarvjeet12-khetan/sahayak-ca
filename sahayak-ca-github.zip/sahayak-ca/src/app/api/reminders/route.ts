import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const reminders = await db.reminder.findMany({
      orderBy: { dueDate: "asc" },
    });
    return NextResponse.json({ reminders });
  } catch (err) {
    console.error("GET /api/reminders error:", err);
    return NextResponse.json({ reminders: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const reminder = await db.reminder.create({
      data: {
        title: body.title,
        description: body.description || null,
        dueDate: new Date(body.dueDate),
        category: body.category || "other",
        status: body.status || "pending",
      },
    });
    return NextResponse.json({ reminder });
  } catch (err) {
    console.error("POST /api/reminders error:", err);
    return NextResponse.json({ error: "Failed to save reminder" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status } = body;
    if (!id || !status) return NextResponse.json({ error: "id and status required" }, { status: 400 });
    const reminder = await db.reminder.update({
      where: { id },
      data: { status },
    });
    return NextResponse.json({ reminder });
  } catch (err) {
    console.error("PATCH /api/reminders error:", err);
    return NextResponse.json({ error: "Failed to update reminder" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.reminder.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/reminders error:", err);
    return NextResponse.json({ error: "Failed to delete reminder" }, { status: 500 });
  }
}
