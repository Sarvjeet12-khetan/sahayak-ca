import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const invoices = await db.invoice.findMany({
      orderBy: { invoiceDate: "desc" },
      include: { items: true },
      take: 50,
    });
    return NextResponse.json({ invoices });
  } catch (err) {
    console.error("GET /api/invoices error:", err);
    return NextResponse.json({ invoices: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const invoice = await db.invoice.create({
      data: {
        invoiceNumber: body.invoiceNumber,
        invoiceDate: new Date(body.invoiceDate),
        customerName: body.customerName,
        customerGstin: body.customerGstin || null,
        customerState: body.customerState || null,
        placeOfSupply: body.placeOfSupply || null,
        isInterState: !!body.isInterState,
        itemsJson: JSON.stringify(body.items || []),
        totalAmount: Number(body.totalAmount) || 0,
        totalCgst: Number(body.totalCgst) || 0,
        totalSgst: Number(body.totalSgst) || 0,
        totalIgst: Number(body.totalIgst) || 0,
        totalTax: Number(body.totalTax) || 0,
        grandTotal: Number(body.grandTotal) || 0,
        notes: body.notes || null,
        status: body.status || "issued",
        items: {
          create: (body.items || []).map((it: any) => ({
            description: it.description,
            hsn: it.hsn,
            quantity: Number(it.quantity) || 0,
            rate: Number(it.rate) || 0,
            gstRate: Number(it.gstRate) || 0,
            amount: Number(it.amount) || 0,
            cgst: Number(it.cgst) || 0,
            sgst: Number(it.sgst) || 0,
            igst: Number(it.igst) || 0,
            taxAmount: Number(it.taxAmount) || 0,
            total: Number(it.total) || 0,
          })),
        },
      },
      include: { items: true },
    });
    return NextResponse.json({ invoice });
  } catch (err) {
    console.error("POST /api/invoices error:", err);
    return NextResponse.json({ error: "Failed to save invoice" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.invoice.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/invoices error:", err);
    return NextResponse.json({ error: "Failed to delete invoice" }, { status: 500 });
  }
}
