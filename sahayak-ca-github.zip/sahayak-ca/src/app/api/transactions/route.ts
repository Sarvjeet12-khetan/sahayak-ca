import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const transactions = await db.transaction.findMany({
      orderBy: { date: "desc" },
      take: 100,
    });
    return NextResponse.json({ transactions });
  } catch (err) {
    console.error("GET /api/transactions error:", err);
    return NextResponse.json({ transactions: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const tx = await db.transaction.create({
      data: {
        date: new Date(body.date),
        type: body.type, // income | expense
        category: body.category,
        description: body.description,
        amount: Number(body.amount) || 0,
        gstRate: body.gstRate != null ? Number(body.gstRate) : null,
        isGstRegistered: !!body.isGstRegistered,
      },
    });
    return NextResponse.json({ transaction: tx });
  } catch (err) {
    console.error("POST /api/transactions error:", err);
    return NextResponse.json({ error: "Failed to save transaction" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.transaction.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/transactions error:", err);
    return NextResponse.json({ error: "Failed to delete transaction" }, { status: 500 });
  }
}
