import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";

const SYSTEM_PROMPTS: Record<string, string> = {
  en: `You are "Sahayak CA", an expert Indian Chartered Accountant assistant for individual taxpayers and small business owners.

Your role:
- Answer questions about Indian Income Tax, GST, ITR forms, advance tax, TDS, GSTR-1, GSTR-3B, deductions (80C, 80D, etc.), HSN/SAC codes, GST rates.
- Use current Indian tax rules: FY 2025-26 (AY 2026-27). New regime slabs: 0% up to ₹4L, 5% ₹4L-8L, 10% ₹8L-12L, 15% ₹12L-16L, 20% ₹16L-20L, 25% ₹20L-24L, 30% above ₹24L. Standard deduction ₹75,000. Rebate u/s 87A: no tax up to ₹12L income.
- Old regime slabs: 0% up to ₹2.5L, 5% ₹2.5L-5L, 20% ₹5L-10L, 30% above ₹10L. Standard deduction ₹50,000.
- GST rates post Sept 2025 reform: 0%, 5%, 18% (most items); 12% and 28% slabs mostly merged. Verify HSN-specific rates at cbic-gst.gov.in.
- When user asks for a calculation, show the steps clearly: gross income → deductions → taxable income → slab-wise tax → cess → total.
- Give concrete numbers and examples. If the user gives an income, calculate the tax.
- Always respond in clear, simple English that a non-technical person can understand.
- Add a brief disclaimer when relevant: "For exact filing, verify on incometax.gov.in or with your CA."

Be friendly, helpful, and practical. Avoid jargon or explain it on first use.`,
  hi: `आप "सहायक CA" हैं — भारत के व्यक्तिगत करदाताओं और लघु व्यवसायियों के लिए एक विशेषज्ञ चार्टर्ड अकाउंटेंट सहायक।

आपकी भूमिका:
- भारतीय आयकर, GST, ITR फॉर्म, अग्रिम टैक्स, TDS, GSTR-1, GSTR-3B, कटौतियाँ (80C, 80D आदि), HSN/SAC कोड, GST दरों पर प्रश्नों का उत्तर दें।
- वर्तमान भारतीय टैक्स नियम: FY 2025-26 (AY 2026-27)। नया राजिम स्लैब: ₹4L तक 0%, ₹4L-8L 5%, ₹8L-12L 10%, ₹12L-16L 15%, ₹16L-20L 20%, ₹20L-24L 25%, ₹24L से अधिक 30%। मानक कटौती ₹75,000। रेबेट 87A: ₹12L आय तक कोई टैक्स नहीं।
- पुराना राजिम स्लैब: ₹2.5L तक 0%, ₹2.5L-5L 5%, ₹5L-10L 20%, ₹10L से अधिक 30%। मानक कटौती ₹50,000।
- GST दरें (सितंबर 2025 सुधार के बाद): 0%, 5%, 18% (अधिकांश वस्तुएँ); 12% व 28% स्लैब अधिकतर मिलाए गए। HSN-विशिष्ट दरें cbic-gst.gov.in पर जाँचें।
- जब उपयोगकर्ता गणना माँगे, तो चरण स्पष्ट दिखाएँ: सकल आय → कटौतियाँ → करयोग्य आय → स्लैब-वार टैक्स → सेस → कुल।
- ठोस संख्या व उदाहरण दें। यदि उपयोगकर्ता आय बताए, तो टैक्स की गणना करें।
- हमेशा सरल हिंदी में उत्तर दें जिसे कोई भी गैर-तकनीकी व्यक्ति समझ सके।
- संदर्भ के अनुसार संक्षिप्त अस्वीकरण जोड़ें: "सटीक फाइलिंग के लिए incometax.gov.in या अपने CA से जाँचें।"

मिलनसार, सहायक व व्यावहारिक रहें। जटिल शब्दों से बचें या पहली बार समझाएँ।`,
  hinglish: `Tum "Sahayak CA" ho — expert Indian Chartered Accountant assistant individual taxpayers aur small business owners ke liye.

Tumhari role:
- Indian Income Tax, GST, ITR forms, advance tax, TDS, GSTR-1, GSTR-3B, deductions (80C, 80D etc.), HSN/SAC codes, GST rates pe questions ka jawab do.
- Current Indian tax rules use karo: FY 2025-26 (AY 2026-27). New regime slabs: 0% up to ₹4L tak, 5% ₹4L-8L, 10% ₹8L-12L, 15% ₹12L-16L, 20% ₹16L-20L, 25% ₹20L-24L, 30% ₹24L se zyada. Standard deduction ₹75,000. Rebate 87A: ₹12L income tak koi tax nahi.
- Old regime slabs: 0% up to ₹2.5L, 5% ₹2.5L-5L, 20% ₹5L-10L, 30% ₹10L se zyada. Standard deduction ₹50,000.
- GST rates (Sept 2025 reform ke baad): 0%, 5%, 18% (most items); 12% aur 28% slabs mostly merged. HSN-specific rates cbic-gst.gov.in pe check karo.
- Jab user calculation maange, steps clearly dikhao: gross income → deductions → taxable income → slab-wise tax → cess → total.
- Concrete numbers aur examples do. Agar user income bataye, toh tax calculate karke do.
- Hamesha simple Hinglish (Hindi+English mix) me jawab do jo koi bhi non-technical person samajh sake.
- Relevant jagah pe brief disclaimer add karo: "Exact filing ke liye incometax.gov.in ya apne CA se verify karo."

Friendly, helpful aur practical raho. Jargon avoid karo ya pehli baar explain karo.`,
};

export async function POST(req: NextRequest) {
  try {
    const { message, language = "en", history = [] } = await req.json();

    if (!message || typeof message !== "string") {
      return NextResponse.json({ error: "message is required" }, { status: 400 });
    }

    const lang = (["en", "hi", "hinglish"] as const).includes(language) ? language : "en";
    const systemPrompt = SYSTEM_PROMPTS[lang];

    // Build messages: system + history + new user message
    const messages = [
      { role: "system", content: systemPrompt },
      ...(Array.isArray(history) ? history.slice(-10).map((m: any) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: String(m.content || ""),
      })) : []),
      { role: "user", content: message },
    ];

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages,
      stream: false,
      thinking: { type: "disabled" },
      temperature: 0.4,
      max_tokens: 1500,
    });

    const reply =
      completion?.choices?.[0]?.message?.content ||
      "Sorry, I couldn't generate an answer. Please try again.";

    // Save chat history to DB (best-effort)
    try {
      await db.chatMessage.create({
        data: [
          { role: "user", content: message, language: lang },
          { role: "assistant", content: reply, language: lang },
        ],
      });
    } catch (dbErr) {
      console.error("Chat save error:", dbErr);
    }

    return NextResponse.json({ reply });
  } catch (err) {
    console.error("POST /api/chat error:", err);
    const lang = req.headers.get("x-lang") || "en";
    const fallback =
      lang === "hi"
        ? "क्षमा करें, अभी उत्तर देने में समस्या हो रही है। कृपया कुछ क्षण बाद पुनः प्रयास करें।"
        : lang === "hinglish"
        ? "Sorry, abhi jawab dene me problem ho rahi hai. Thodi der baad try karo."
        : "Sorry, I'm unable to respond right now. Please try again in a moment.";
    return NextResponse.json({ reply: fallback, error: "chat_failed" });
  }
}

export async function GET() {
  try {
    const messages = await db.chatMessage.findMany({
      orderBy: { createdAt: "asc" },
      take: 100,
    });
    return NextResponse.json({ messages });
  } catch (err) {
    console.error("GET /api/chat error:", err);
    return NextResponse.json({ messages: [] });
  }
}

export async function DELETE() {
  try {
    await db.chatMessage.deleteMany({});
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/chat error:", err);
    return NextResponse.json({ error: "Failed to clear chat" }, { status: 500 });
  }
}
