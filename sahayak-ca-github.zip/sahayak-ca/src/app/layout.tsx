import type { Metadata } from "next";
import { Inter, Lora, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const lora = Lora({
  variable: "--font-lora",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Sahayak CA — Bharat Tax & GST Assistant",
  description:
    "All-in-one Indian CA assistant: GST filing, income tax calculation, invoicing, bookkeeping, AI chat advisor and reminders. Easy enough for anyone to use, powerful enough for small businesses.",
  keywords: [
    "CA assistant",
    "India tax",
    "GST calculator",
    "income tax calculator",
    "GSTR-1",
    "GSTR-3B",
    "ITR",
    "invoicing",
    "bookkeeping",
    "Hindi tax",
    "Hinglish CA",
  ],
  authors: [{ name: "Sahayak CA" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Sahayak CA — Bharat Tax & GST Assistant",
    description:
      "All-in-one Indian CA assistant. GST, income tax, invoicing, bookkeeping, AI advisor. Easy for everyone.",
    url: "https://chat.z.ai",
    siteName: "Sahayak CA",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${lora.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
