"use client";

import { useState, useEffect } from "react";
import { Header } from "@/components/ca/Header";
import { TabNav } from "@/components/ca/TabNav";
import { Dashboard } from "@/components/ca/Dashboard";
import { GSTTools } from "@/components/ca/GSTTools";
import { IncomeTax } from "@/components/ca/IncomeTax";
import { InvoiceBuilder } from "@/components/ca/InvoiceBuilder";
import { Bookkeeping } from "@/components/ca/Bookkeeping";
import { AIAdvisor } from "@/components/ca/AIAdvisor";
import { Reminders } from "@/components/ca/Reminders";
import { ProfileSetup } from "@/components/ca/ProfileSetup";
import { Footer } from "@/components/ca/Footer";
import { type TabKey, type ProfileData } from "@/components/ca/types";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabKey>("dashboard");
  const [profileOpen, setProfileOpen] = useState(false);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [profileLoaded, setProfileLoaded] = useState(false);

  // Dashboard data
  const [invoiceCount, setInvoiceCount] = useState(0);
  const [transactions, setTransactions] = useState<Array<{ type: string; amount: number }>>([]);
  const [customReminders, setCustomReminders] = useState<Array<{ id: string; title: string; dueDate: string; status: string }>>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/profile");
        const data = await res.json();
        if (cancelled) return;
        if (data.profile) {
          setProfile({
            name: data.profile.name,
            pan: data.profile.pan,
            gstin: data.profile.gstin,
            aadhaar: data.profile.aadhaar,
            mobile: data.profile.mobile,
            email: data.profile.email,
            address: data.profile.address,
            state: data.profile.state,
            userType: data.profile.userType,
            businessName: data.profile.businessName,
            regime: data.profile.regime,
          });
        } else {
          setProfile(null);
          setProfileOpen(true);
        }
        setProfileLoaded(true);
      } catch {
        if (!cancelled) setProfileLoaded(true);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [invRes, txRes, remRes] = await Promise.all([
          fetch("/api/invoices").then((r) => r.json()),
          fetch("/api/transactions").then((r) => r.json()),
          fetch("/api/reminders").then((r) => r.json()),
        ]);
        if (cancelled) return;
        const now = new Date();
        const thisMonth = now.getMonth();
        const thisYear = now.getFullYear();
        const monthInvCount = (invRes.invoices || []).filter((i: any) => {
          const d = new Date(i.invoiceDate);
          return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
        }).length;
        setInvoiceCount(monthInvCount);
        setTransactions((txRes.transactions || []).map((t: any) => ({ type: t.type, amount: t.amount })));
        setCustomReminders((remRes.reminders || []).map((r: any) => ({
          id: r.id,
          title: r.title,
          dueDate: r.dueDate,
          status: r.status,
        })));
      } catch {
        // ignore
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const reloadDashboard = () => {
    // Trigger a refetch by re-running the dashboard effect via state change pattern
    // Simplest: re-fetch directly
    (async () => {
      try {
        const [invRes, txRes, remRes] = await Promise.all([
          fetch("/api/invoices").then((r) => r.json()),
          fetch("/api/transactions").then((r) => r.json()),
          fetch("/api/reminders").then((r) => r.json()),
        ]);
        const now = new Date();
        const thisMonth = now.getMonth();
        const thisYear = now.getFullYear();
        const monthInvCount = (invRes.invoices || []).filter((i: any) => {
          const d = new Date(i.invoiceDate);
          return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
        }).length;
        setInvoiceCount(monthInvCount);
        setTransactions((txRes.transactions || []).map((t: any) => ({ type: t.type, amount: t.amount })));
        setCustomReminders((remRes.reminders || []).map((r: any) => ({
          id: r.id,
          title: r.title,
          dueDate: r.dueDate,
          status: r.status,
        })));
      } catch {
        // ignore
      }
    })();
  };

  const handleProfileSaved = (p: ProfileData) => {
    setProfile(p);
    reloadDashboard();
  };

  // Compute dashboard snapshot values
  const totalIncome = transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const totalExpense = transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const netCash = totalIncome - totalExpense;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header onOpenProfile={() => setProfileOpen(true)} profileName={profile?.name} />

      <TabNav active={activeTab} onChange={setActiveTab} />

      <main className="flex-1 mx-auto max-w-7xl w-full px-4 sm:px-6 py-4 sm:py-6 pb-20 md:pb-6">
        {!profileLoaded ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-pulse text-muted-foreground">Loading…</div>
          </div>
        ) : (
          <>
            {activeTab === "dashboard" && (
              <Dashboard
                onNavigate={setActiveTab}
                profileName={profile?.name}
                invoiceCount={invoiceCount}
                taxLiability={null}
                gstPayable={null}
                netCash={netCash}
                customReminders={customReminders}
              />
            )}
            {activeTab === "gst" && <GSTTools />}
            {activeTab === "incometax" && <IncomeTax />}
            {activeTab === "invoices" && (
              <InvoiceBuilder profile={profile} onSaved={reloadDashboard} />
            )}
            {activeTab === "books" && <Bookkeeping />}
            {activeTab === "advisor" && <AIAdvisor />}
            {activeTab === "reminders" && <Reminders />}
          </>
        )}
      </main>

      <Footer />

      <ProfileSetup
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        onSaved={handleProfileSaved}
      />
    </div>
  );
}

