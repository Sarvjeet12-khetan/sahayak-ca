// Indian Tax Calculation Library
// FY 2025-26 / AY 2026-27 — Based on Budget 2025 announcements

export interface GstBreakdown {
  baseAmount: number;
  gstRate: number;
  gstAmount: number;
  cgst: number;
  sgst: number;
  igst: number;
  total: number;
}

/**
 * Add GST (tax-exclusive) to an amount.
 * @param amount base amount before GST
 * @param ratePercent GST rate (0, 5, 12, 18, 28)
 * @param interState if true → IGST; else split CGST+SGST
 */
export function addGst(amount: number, ratePercent: number, interState: boolean): GstBreakdown {
  const gstAmount = (amount * ratePercent) / 100;
  const total = amount + gstAmount;
  return {
    baseAmount: amount,
    gstRate: ratePercent,
    gstAmount,
    cgst: interState ? 0 : gstAmount / 2,
    sgst: interState ? 0 : gstAmount / 2,
    igst: interState ? gstAmount : 0,
    total,
  };
}

/**
 * Remove GST (tax-inclusive) from an amount.
 * @param amount total amount including GST
 * @param ratePercent GST rate
 * @param interState if true → IGST; else split CGST+SGST
 */
export function removeGst(amount: number, ratePercent: number, interState: boolean): GstBreakdown {
  const baseAmount = amount / (1 + ratePercent / 100);
  const gstAmount = amount - baseAmount;
  return {
    baseAmount,
    gstRate: ratePercent,
    gstAmount,
    cgst: interState ? 0 : gstAmount / 2,
    sgst: interState ? 0 : gstAmount / 2,
    igst: interState ? gstAmount : 0,
    total: amount,
  };
}

// ============ Income Tax ============

// New Regime slabs — FY 2025-26 (AY 2026-27), per Budget 2025
export const NEW_REGIME_SLABS = [
  { upTo: 400000, rate: 0 },
  { upTo: 800000, rate: 0.05 },
  { upTo: 1200000, rate: 0.10 },
  { upTo: 1600000, rate: 0.15 },
  { upTo: 2000000, rate: 0.20 },
  { upTo: 2400000, rate: 0.25 },
  { upTo: Infinity, rate: 0.30 },
];

// Old Regime slabs — FY 2025-26 (AY 2026-27)
export const OLD_REGIME_SLABS = [
  { upTo: 250000, rate: 0 },
  { upTo: 500000, rate: 0.05 },
  { upTo: 1000000, rate: 0.20 },
  { upTo: Infinity, rate: 0.30 },
];

export const STANDARD_DEDUCTION_NEW = 75000;
export const STANDARD_DEDUCTION_OLD = 50000;
export const REBATE_87A_NEW_LIMIT = 1200000; // No tax up to ₹12L in new regime
export const REBATE_87A_NEW_MAX = 60000;
export const REBATE_87A_OLD_LIMIT = 500000;
export const REBATE_87A_OLD_MAX = 12500;
export const CESS_RATE = 0.04;

export interface IncomeTaxInput {
  regime: "new" | "old";
  salaryIncome: number;
  otherIncome: number;
  deduction80C: number; // old regime only, max 150000
  deduction80D: number; // old regime only
  deduction80G: number; // old regime only
  deductionHRA: number; // old regime only
  deductionHome: number; // old regime only, max 200000
}

export interface IncomeTaxResult {
  grossIncome: number;
  totalDeductions: number;
  taxableIncome: number;
  taxBeforeCess: number;
  rebate: number;
  cess: number;
  totalTax: number;
  effectiveRate: number;
  monthlyTax: number;
}

function computeSlabTax(income: number, slabs: { upTo: number; rate: number }[]): number {
  let tax = 0;
  let prev = 0;
  for (const s of slabs) {
    if (income <= prev) break;
    const slice = Math.min(income, s.upTo) - prev;
    if (slice > 0) tax += slice * s.rate;
    prev = s.upTo;
  }
  return tax;
}

export function computeIncomeTax(input: IncomeTaxInput): IncomeTaxResult {
  const grossIncome = (input.salaryIncome || 0) + (input.otherIncome || 0);

  let deductions = 0;
  let stdDeduction = 0;
  if (input.regime === "new") {
    // New regime: standard deduction only (salary income assumed), most other deductions not allowed
    if (input.salaryIncome > 0) {
      stdDeduction = STANDARD_DEDUCTION_NEW;
    }
    deductions = stdDeduction;
  } else {
    if (input.salaryIncome > 0) {
      stdDeduction = STANDARD_DEDUCTION_OLD;
    }
    const d80C = Math.min(input.deduction80C || 0, 150000);
    const d80D = Math.min(input.deduction80D || 0, 100000);
    const d80G = input.deduction80G || 0;
    const dHRA = input.deductionHRA || 0;
    const dHome = Math.min(input.deductionHome || 0, 200000);
    deductions = stdDeduction + d80C + d80D + d80G + dHRA + dHome;
  }

  const taxableIncome = Math.max(0, grossIncome - deductions);
  const slabs = input.regime === "new" ? NEW_REGIME_SLABS : OLD_REGIME_SLABS;
  const taxBeforeCess = computeSlabTax(taxableIncome, slabs);

  // Rebate u/s 87A
  let rebate = 0;
  if (input.regime === "new") {
    if (taxableIncome <= REBATE_87A_NEW_LIMIT) {
      rebate = Math.min(taxBeforeCess, REBATE_87A_NEW_MAX);
    }
  } else {
    if (taxableIncome <= REBATE_87A_OLD_LIMIT) {
      rebate = Math.min(taxBeforeCess, REBATE_87A_OLD_MAX);
    }
  }

  const taxAfterRebate = Math.max(0, taxBeforeCess - rebate);
  const cess = taxAfterRebate * CESS_RATE;
  const totalTax = taxAfterRebate + cess;
  const effectiveRate = grossIncome > 0 ? (totalTax / grossIncome) * 100 : 0;
  const monthlyTax = totalTax / 12;

  return {
    grossIncome,
    totalDeductions: deductions,
    taxableIncome,
    taxBeforeCess,
    rebate,
    cess,
    totalTax,
    effectiveRate,
    monthlyTax,
  };
}

// ============ Advance Tax Schedule ============
// For estimated annual tax > ₹10,000, advance tax installments
export interface AdvanceTaxInstallment {
  dueDate: string;
  percent: number;
  amount: number;
  label: string;
}

export function computeAdvanceTax(annualTax: number): AdvanceTaxInstallment[] {
  if (annualTax <= 10000) return [];
  return [
    { dueDate: "15 June", percent: 15, amount: annualTax * 0.15, label: "1st Installment" },
    { dueDate: "15 September", percent: 45, amount: annualTax * 0.45, label: "2nd Installment" },
    { dueDate: "15 December", percent: 75, amount: annualTax * 0.75, label: "3rd Installment" },
    { dueDate: "15 March", percent: 100, amount: annualTax, label: "4th Installment (Full)" },
  ];
}

// ============ GSTR Summary ============
export interface GstrInput {
  sales5: number;
  sales12: number;
  sales18: number;
  sales28: number;
  sales0: number;
}

export interface GstrResult {
  totalSales: number;
  totalTax: number;
  breakdown: { rate: number; base: number; tax: number; total: number }[];
}

export function computeGstr(input: GstrInput): GstrResult {
  const rates = [5, 12, 18, 28, 0];
  const amounts = [input.sales5, input.sales12, input.sales18, input.sales28, input.sales0];
  const breakdown = rates.map((rate, i) => {
    const base = amounts[i] || 0;
    const tax = (base * rate) / 100;
    return { rate, base, tax, total: base + tax };
  });
  const totalSales = breakdown.reduce((s, b) => s + b.base, 0);
  const totalTax = breakdown.reduce((s, b) => s + b.tax, 0);
  return { totalSales, totalTax, breakdown };
}

// ============ Official Compliance Dates ============
export interface ComplianceDate {
  title: string;
  description: string;
  category: "gst" | "income_tax" | "advance_tax" | "itr";
  // Returns the next occurrence date for a given "from" date
  getNextDate: (from: Date) => Date;
}

// GST monthly GSTR-1: 11th of next month
// GST monthly GSTR-3B: 20th of next month
// GST quarterly (QRMP scheme) GSTR-1 & 3B: 22nd or 24th of next month after quarter

export const COMPLIANCE_DATES: ComplianceDate[] = [
  {
    title: "GSTR-1 (Monthly)",
    description: "File details of outward supplies of goods/services for previous month.",
    category: "gst",
    getNextDate: (from) => {
      // 11th of next month
      const d = new Date(from.getFullYear(), from.getMonth() + 1, 11);
      if (d <= from) d.setMonth(d.getMonth() + 1);
      return d;
    },
  },
  {
    title: "GSTR-3B (Monthly)",
    description: "File summary return and pay tax for previous month.",
    category: "gst",
    getNextDate: (from) => {
      const d = new Date(from.getFullYear(), from.getMonth() + 1, 20);
      if (d <= from) d.setMonth(d.getMonth() + 1);
      return d;
    },
  },
  {
    title: "GSTR-1 & 3B (QRMP Quarterly)",
    description: "For small taxpayers under ₹1.5 crore turnover — 22nd (or 24th for select states) of next month after quarter.",
    category: "gst",
    getNextDate: (from) => {
      // Next quarter end + 22 days
      const month = from.getMonth();
      const quarterEndMonth = Math.ceil((month + 1) / 3) * 3 - 1; // Mar, Jun, Sep, Dec
      let d = new Date(from.getFullYear(), quarterEndMonth + 1, 22);
      if (d <= from) {
        d = new Date(from.getFullYear(), quarterEndMonth + 4, 22);
      }
      return d;
    },
  },
  {
    title: "Advance Tax — 1st Installment (15%)",
    description: "Pay 15% of estimated annual tax by 15th June.",
    category: "advance_tax",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const june15 = new Date(year, 5, 15);
      if (june15 >= from) return june15;
      return new Date(year + 1, 5, 15);
    },
  },
  {
    title: "Advance Tax — 2nd Installment (45%)",
    description: "Cumulative 45% of estimated tax by 15th September.",
    category: "advance_tax",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const sep15 = new Date(year, 8, 15);
      if (sep15 >= from) return sep15;
      return new Date(year + 1, 8, 15);
    },
  },
  {
    title: "Advance Tax — 3rd Installment (75%)",
    description: "Cumulative 75% of estimated tax by 15th December.",
    category: "advance_tax",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const dec15 = new Date(year, 11, 15);
      if (dec15 >= from) return dec15;
      return new Date(year + 1, 11, 15);
    },
  },
  {
    title: "Advance Tax — Final Installment (100%)",
    description: "Pay 100% of estimated tax by 15th March.",
    category: "advance_tax",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const mar15 = new Date(year, 2, 15);
      if (mar15 >= from) return mar15;
      return new Date(year + 1, 2, 15);
    },
  },
  {
    title: "ITR Filing (Non-Audit Cases)",
    description: "File your Income Tax Return by 31st July (individual/salaried/small business without audit).",
    category: "itr",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const jul31 = new Date(year, 6, 31);
      if (jul31 >= from) return jul31;
      return new Date(year + 1, 6, 31);
    },
  },
  {
    title: "ITR Filing (Audit Cases)",
    description: "Companies & audit-required firms — file by 31st October.",
    category: "itr",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const oct31 = new Date(year, 9, 31);
      if (oct31 >= from) return oct31;
      return new Date(year + 1, 9, 31);
    },
  },
  {
    title: "Tax Audit Report (Form 10B/3CD)",
    description: "Get audit report filed by 30th September (audit-required entities).",
    category: "itr",
    getNextDate: (from) => {
      const year = from.getFullYear();
      const sep30 = new Date(year, 8, 30);
      if (sep30 >= from) return sep30;
      return new Date(year + 1, 8, 30);
    },
  },
];

// ============ Helper formatting ============
export function formatINR(amount: number): string {
  // Indian grouping: 1,00,000 (lakh)
  const sign = amount < 0 ? "-" : "";
  const abs = Math.abs(amount);
  const parts = abs.toFixed(2).split(".");
  let intPart = parts[0];
  let lastThree = intPart.slice(-3);
  const otherNumbers = intPart.slice(0, -3);
  if (otherNumbers !== "") {
    lastThree = "," + lastThree;
  }
  const formattedOther = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",");
  intPart = formattedOther + lastThree;
  return `${sign}₹${intPart}.${parts[1]}`;
}

export function formatINRShort(amount: number): string {
  const sign = amount < 0 ? "-" : "";
  const abs = Math.abs(amount);
  if (abs >= 10000000) return `${sign}₹${(abs / 10000000).toFixed(2)} Cr`;
  if (abs >= 100000) return `${sign}₹${(abs / 100000).toFixed(2)} L`;
  if (abs >= 1000) return `${sign}₹${(abs / 1000).toFixed(1)}K`;
  return `${sign}₹${abs.toFixed(0)}`;
}

export function formatDateIST(date: Date): string {
  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: "Asia/Kolkata",
  });
}

// HSN/SAC code common samples for invoicing
export const SAMPLE_HSN_CODES: { code: string; desc: string; rate: number }[] = [
  { code: "998314", desc: "IT / Software services", rate: 18 },
  { code: "9985", desc: "Management consulting", rate: 18 },
  { code: "997331", desc: "Licensing of software", rate: 18 },
  { code: "9984", desc: "Advertising services", rate: 18 },
  { code: "9986", desc: "Engineering services", rate: 18 },
  { code: "9982", desc: "Legal services", rate: 18 },
  { code: "9987", desc: "Financial advisory", rate: 18 },
  { code: "0101", desc: "Live animals (horses, etc.)", rate: 5 },
  { code: "1006", desc: "Rice", rate: 0 },
  { code: "1701", desc: "Sugar", rate: 5 },
  { code: "2106", desc: "Food preparations", rate: 18 },
  { code: "2202", desc: "Soft drinks", rate: 28 },
  { code: "3004", desc: "Medicines (packaged)", rate: 12 },
  { code: "4202", desc: "Bags & suitcases", rate: 18 },
  { code: "6109", desc: "T-shirts", rate: 5 },
  { code: "8517", desc: "Smartphones", rate: 18 },
  { code: "8703", desc: "Motor cars", rate: 28 },
  { code: "9403", desc: "Furniture", rate: 18 },
];

export const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
  "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
  "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
  "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
  "Uttar Pradesh", "Uttarakhand", "West Bengal", "Delhi", "Jammu & Kashmir",
  "Ladakh", "Chandigarh", "Puducherry", "Andaman & Nicobar", "Dadra & Nagar Haveli and Daman & Diu",
  "Lakshadweep", "Other / Not Listed",
];
